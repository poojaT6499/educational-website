<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Eloquent;

class Plan extends Model   {

    protected $table = 'plan';
    public $timestamps = false;
    protected $primaryKey = 'planID';

   

   
  
}