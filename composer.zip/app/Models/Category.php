<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Eloquent;

class Category extends Eloquent  {

    protected $table = 'category';
}