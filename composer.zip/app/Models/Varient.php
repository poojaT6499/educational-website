<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Eloquent;

class Varient extends Eloquent  {

    protected $table = 'varient';
}