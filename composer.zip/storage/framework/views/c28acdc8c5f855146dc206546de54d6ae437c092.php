

<?php $__env->startSection('content'); ?>
<section class="main-header" style="background-image:url(assets/images/productbanner.jpg)">
    <!-- <header class="hidden"> -->
        <div class="container text-center">
            <h1 class="h2 title">T & C</h1>
        </div>
    <!-- </header> -->
</section>

<!-- ========================  Products ======================== -->

<section class="products">
    <div class="container">

        <header>
            <div class="row">
                <div class="col-md-offset-2 col-md-8 text-center">
                    <h2 class="title">Terms & Conditions</h2><br>
                    <div class="text">
                        <h6>TENURE </h6>
                        <p>The minimum tenure for this product is 6 months. If you return this product anytime
                            before the minimum tenure, you will be charged rent for the minimum months.</p>
                        <p>If the customer has paid deposit and has accepted furniture delivery, the deposit is
                            non –refundable if the product is returned within in minimum rental tenure of the
                            product from the date of delivery of the product.</p>
                        <h6>BILLING</h6>
                        <p>The customer's billing cycle starts on the date the first item is delivered to
                            his/her house. The subscription cycle is then that date plus one month. Every
                            subsequent item/package delivered is invoiced pro-rate in accordance with the
                            subscription cycle.
                            Any subsequent add-on, swap, etc will be invoiced in accordance with the
                            subscription cycle.
                            Customer will receive Invoice on his mail .</p>
                        <h6>PAYMENT</h6>
                        <p>Customer should pay products Rent by 5th of every month. Delayed payment of monthly
                            rentals beyond due date shall attract a late payment charge of the outstanding
                            amount or Rs. 450 per month, till the time the monthly rental is paid.
                            Non-payment of monthly rentals for one month could result in termination of
                            subscription and removal of the furniture
                            The Company will levy a charge of Rs. 500/- for ECS/Standing Instructions dishonor.
                        </p>
                        <h6>DELIVERY
                        </h6>
                        <p>In case of partial, damaged or incorrect delivery, the replacement is done in 48
                            hours<br>
                            We adhere strictly to our delivery time lines confirmed earlier by our in-house
                            Customer Care team. In rare instances when delivery is delayed, we inform our
                            customers two hours in advance for any delay.<br>
                            There are no maximum number of delivery attempts. Customer is contacted repeatedly
                            and attempts are made till delivery is completed. It is in the best interests of the
                            customer to avail of delivery in the first two attempts, as delivery to other
                            customers would have to take precedence if the first two delivery attempts are
                            missed by the customer</p>
                        <h6>CONTRACT</h6>
                        <p>The receiver of furniture would have to sign off the Agreement Document (detailing
                            the subscription Terms and Conditions, benefits of subscription and other relevant
                            information) and the Check List of items received.
                            During time of delivery, the customer is requested to check and verify the quality
                            and details of each piece of furniture being set up. This is to ensure that the
                            customer receives exactly what has been ordered to his satisfaction.
                            There is a quality checklist that customer can go through and sign off conveying
                            that he/she is happy with the product quality.
                        </p>

                    </div>
                </div>
            </div>
        </header>



    </div>
    <!--/container-->
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/layouts/terms.blade.php ENDPATH**/ ?>