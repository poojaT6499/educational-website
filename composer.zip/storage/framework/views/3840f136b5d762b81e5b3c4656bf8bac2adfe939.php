<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
        <!-- Mobile Web-app fullscreen -->
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="mobile-web-app-capable" content="yes">
    
        <!-- Meta tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        
    
        <!--Title-->
        <title>RentoFurnish - Rent Premium Furniture </title>
    
        <!--CSS styles-->
        <link rel="stylesheet" media="all" href="<?php echo e(asset('/css/bootstrap.css')); ?>" />
        <link rel="stylesheet" media="all" href="<?php echo e(asset('/css/animate.css')); ?>" />
        <link rel="stylesheet" media="all" href="<?php echo e(asset('/css/font-awesome.css')); ?>" />
        <link rel="stylesheet" media="all" href="<?php echo e(asset('/css/furniture-icons.css')); ?>" />
        <link rel="stylesheet" media="all" href="<?php echo e(asset('/css/linear-icons.css')); ?>" />
        <link rel="stylesheet" media="all" href="<?php echo e(asset('/css/magnific-popup.css')); ?>" />
        <link rel="stylesheet" media="all" href="<?php echo e(asset('/css/owl.carousel.css')); ?>" />
        <link rel="stylesheet" media="all" href="<?php echo e(asset('/css/ion-range-slider.css')); ?>" />
        <link rel="stylesheet" media="all" href="<?php echo e(asset('/css/theme.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    
        <!--Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600&amp;subset=latin-ext" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">
    
    
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
        
        <!-- <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'> -->
    
    
 </head>
<body>



    <div class="wrapper">
   
        
     <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

     

    </div>
    <!--/wrapper-->

    <script src="<?php echo e(asset('/js/jquery.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('/js/jquery.bootstrap.js')); ?>" defer></script>
    <script src="<?php echo e(asset('/js/jquery.magnific-popup.js')); ?>" defer></script>
    <script src="<?php echo e(asset('/js/jquery.owl.carousel.js')); ?>" defer></script>
    <script src="<?php echo e(asset('/js/jquery.ion.rangeSlider.js')); ?>" defer></script>
    <script src="<?php echo e(asset('/js/jquery.isotope.pkgd.js')); ?>" defer></script>
    <script src="<?php echo e(asset('/js/main.js')); ?>" defer></script>
    <script src="<?php echo e(asset('/js/increment.js')); ?>" defer></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
   

</body>

</html><?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/inc/base.blade.php ENDPATH**/ ?>