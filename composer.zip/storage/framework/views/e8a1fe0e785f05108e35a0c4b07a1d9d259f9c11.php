

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Edit Banner</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(Request::root()); ?>/admin/dashboard">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(Request::root()); ?>/admin/Banner">Banner</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(Request::root()); ?>/admin/Banner/add-Banner">Add
                        Banner</a>
                </li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12 col-xxl-12 col-sm-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-body">
                        <form role="form" method="post" action="<?php echo e(Request::root()); ?>/admin/Banner/edit-Banner-post"
                            enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" value="<?php echo $Banner->BannerID ?>" name="BannerID">


                            <div class="form-group">
                                <label for="image">Image:</label>
                                <input type="file" class="btn btn-primary" id="BannerImg" name="BannerImg">
                            </div>
                            <div class="form-group">
                                <label for="description">Order No:</label>
                                <select name="OrderNo">
                                    <option value="">None</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="title">Title:</label>
                                <input type="text" value="<?php echo $Banner->BannerTitle ?>" class="form-control"
                                    id="BannerTitle" name="BannerTitle">
                            </div>

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\learningApp\resources\views/admin/banner/edit.blade.php ENDPATH**/ ?>