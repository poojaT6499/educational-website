<footer>
    <div class="container">

        <!--footer showroom-->
        <!-- <div class="footer-showroom">
            
        </div> -->

        <!--footer links-->
        <div class="footer-links">
            <div class="row">
                <div class="col-sm-12 col-md-3">
                    <h5>Categories</h5>
                    <ul>
                        <li><a href="products-grid.php">Combos</a></li>
                        <li><a href="products-grid.php">Home Furniture</a></li>
                        <li><a href="products-grid.php">Applieances</a></li>
                        <li><a href="products-grid.php">Office Furniture</a></li>
                    </ul>
                </div>
                <div class="col-sm-12 col-md-3">
                    <h5>Quick Links</h5>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                        
                    </ul>
                </div>
                <div class="col-sm-12 col-md-3">
                    <h5>Policies</h5>
                    <ul>
                        <li><a href="policy.php">Privacy Policy</a></li>
                        <li><a href="terms.php">Terms and conditions</a></li>
                        <li><a href="rental.php">Sample Rental Agreement</a></li>
                    </ul>
                </div>
                <div class="col-sm-12 col-md-3">
                <h5>Need Help?</h5>
                    <ul>
                        <li><a href="tel:9136506963"><i class="fa fa-phone" aria-hidden="true">:</i> 9136506963</a></li>
                        <li><a href="javascript:void(0)"><i class="fa fa-envelope-o" aria-hidden="true"></i>  Info@rentofurnish.com</a></li>
                        <!-- <li><a href="">Sample Rental Agreement</a></li> -->
                    </ul>
                    
                    
                </div>
            </div>
        </div>

        <!--footer social-->

        <div class="footer-social">
            <div class="row">
            <div class="col-sm-6" style="color: white;">
                    &#169; Copyright 2022 Rentofurnish. All Rights Reserved.
                </div>
            
                <div class="col-sm-6 links">
                    <ul>
                        <li><a href="https://whatsapp.com/"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                        <li><a href="https://www.facebook.com/Rentofurnish-100355702289278"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://in.linkedin.com/"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        <li><a href="https://in.pinterest.com/"><i class="fa fa-pinterest" aria-hidden="true"></i>                                                                                                               </a></li>
                        <li><a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a></li>
                        <li><a href="https://www.instagram.com/rentofurnish/"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>


<?php /**PATH D:\xampp\htdocs\learningApp\resources\views/inc/footer.blade.php ENDPATH**/ ?>