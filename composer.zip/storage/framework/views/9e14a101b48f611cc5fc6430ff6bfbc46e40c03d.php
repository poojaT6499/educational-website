<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Assign Subjects To <?php echo e($teacher->name); ?></h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>"> Home </a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.teacher')); ?>"> Teachers </a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.teacher.show', $teacher)); ?>"> View Teacher </a></li>
            </ol>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-12 col-xxl-12 col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">All Details</h4>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin.teacher.assign')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <span class="text-muted">Teacher Name: </span> <p class="d-inline"><?php echo e($teacher->name); ?></p>
                            </div>
                            <div class="form-group col-md-4">
                                <span class="text-muted">Phone: </span> <p class="d-inline"><?php echo e($teacher->phone); ?></p>
                            </div>
                            <div class="form-group col-md-4">
                                <span class="text-muted">Email: </span> <p class="d-inline"><?php echo e($teacher->email); ?></p>
                            </div>
                        </div>
                        <hr>
                        <h4 class="card-title">Assign Subjects</h4>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label>Select Class:</label>
                                <select id="classes" class="form-control" name="class_id" onchange="getChapters(this.value);">
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class->id); ?>"><?php echo e($class->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label>Select Subject:</label>
                                <select id="subjects" class="form-control" name="subject_id">
                                </select>
                            </div>
                            <div>
                                
                                <br>
                                <input type="text" name="user_id" value="<?php echo e($teacher->id); ?>" hidden>
                                <button type="submit" class="btn btn-primary mt-2 ml-3">Assign</button>
                            </div>

                        </div>

                    </form>

                    <?php if(Session::has('message')): ?>
                    <div class="alert alert-success">
                        <strong><span class="glyphicon glyphicon-ok"></span><?php echo e(Session::get('message')); ?></strong>
                    </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <?php
                            $classes = $realTeacher->classes;
                            $subjects = $realTeacher->subjects;
                        ?>
                        <?php if(count($classes)>0): ?>
                        <table id="example3" class="display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>
                                    <th>Class</th>
                                    <th>Subject Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i=1;
                                    $j=0;
                                ?>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($i); ?> </td>
                                    <td><?php echo e($class->name); ?></td>
                                    <td><?php echo e($subjects[$j]->name); ?></td>
                                    <td>
                                        <a href="" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger"><i class="la la-trash-o"></i></a>
                                    </td>
                                </tr>

                                <?php
                                    $i++;
                                    $j++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php else: ?>
                        <div class="alert alert-info" role="alert">
                            <strong>No Data Found!</strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<script>
// $(document).ready(function() {
//     console.log( "document loaded" );
// });
window.onload = function() {
    getChapters(1);
};

function removeOptions(selectElement) {
    var i, L = selectElement.options.length - 1;
    for(i = L; i >= 0; i--) {
        selectElement.remove(i);
    }
}

// using the function:
function getChapters(class_id) {
    var subjectsSelect = document.getElementById('subjects');
    removeOptions(subjectsSelect);
    $.ajax({
        type: 'GET',
        url: `<?php echo e(url('/admin/classes/${class_id}/getSubjects')); ?>`,
        data:'_token = <?php echo csrf_token() ?>',
        success: function(response) {
            var subjects = response.subjects;
            subjects.forEach(subject => {
                var subjectsSelect = document.getElementById('subjects');
                subjectsSelect.options[subjectsSelect.options.length] = new Option(subject.name, subject.id);
            });
            $(subjectsSelect).selectpicker('refresh');
        }
    });
};

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/admin/teacher/show.blade.php ENDPATH**/ ?>