

<?php $__env->startSection('content'); ?>


<section class="main-header" style="background-image:url(assets/images/productbanner.jpg)">
    <header>
        <div class="container text-center">
            <h2 class="h2 title">User profile</h2>
            <ol class="breadcrumb breadcrumb-inverted">
                <li><a href="index.php"><span class="icon icon-home"></span></a></li>
                <li><a class="active" href="order.php">Order Details</a></li>
            </ol>
        </div>
    </header>
</section>

<!-- ========================  Login & register ======================== -->
<section class="checkout cart">
    <div class="container mb-4">
        <div class="row">
            <div class="col-lg-3 pb-5">
                <!-- Account Sidebar-->
                <div class="author-card pb-3">
                    <!-- <div class="author-card-cover"
                    style="">
                    <a class="btn btn-style-1 btn-white btn-sm" href="#" data-toggle="tooltip" title=""
                        data-original-title="You currently have 290 Reward points to spend"></a></div> -->
                    <div class="author-card-profile">
                        <div class="author-card-avatar"><img
                                src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="Daniel Adams">
                        </div>
                        <div class="author-card-details">
                            <h5 class="author-card-name text-lg">Daniel Adams</h5><span
                                class="author-card-position">Joined February 06, 2017</span>
                        </div>
                    </div>
                </div>
                <div class="wizard">
                    <nav class="list-group list-group-flush" style="position: static!important;">
                        <a class="list-group-item " href="profile.php">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="d-inline-block font-weight-medium text-uppercase"><i
                                            class="fa fa-user" aria-hidden="true"></i> Profile
                                    </div>
                                </div>
                                <!-- <span class="badge badge-secondary">6</span> -->
                            </div>
                        </a>
                        <a class="list-group-item active" href="order.php" target="__blank"><i
                                class="fa fa-archive" aria-hidden="true"></i> Order List</a>
                        <a class="list-group-item" href="cart.php"><i class="fa fa-shopping-cart"
                                aria-hidden="true"></i>My Cart</a>
                        <a class="list-group-item" href="wishlist.php">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="d-inline-block font-weight-medium text-uppercase"><i
                                            class="fa fa-heart" aria-hidden="true"></i>My Wishlist
                                    </div>
                                </div>
                                <!-- <span class="badge badge-secondary">3</span> -->
                            </div>
                        </a>
                        <a class="list-group-item" href="#" target="__blank">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="d-inline-block font-weight-medium text-uppercase"><i
                                            class="fa fa-user" aria-hidden="true"></i>Logout
                                    </div>
                                </div>
                                <!-- <span class="badge badge-secondary">4</span> -->
                            </div>
                        </a>
                    </nav>
                </div>
            </div>
            <!-- Wishlist-->
            <div class="col-lg-9 pb-5">




                <div class="cart-wrapper">
                    <!--cart header -->

                    <div class="cart-block cart-block-header clearfix">
                        <div>
                            <span>Product</span>
                        </div>
                        <div>
                            <span>&nbsp;</span>
                        </div>
                        <div>
                            <span>Quantity</span>
                        </div>
                        <div class="text-right">
                            <span>Price</span>
                        </div>
                    </div>

                    <!--cart items-->

                    <div class="clearfix">
                        <div class="cart-block cart-block-item clearfix">
                            <div class="image">
                                <a href="product.php"><img src="assets/images/chair3.jpg" alt="" /></a>
                            </div>
                            <div class="title">
                                <div class="h4"><a href="product.php">Green corner</a></div>
                                <div>Green corner</div>
                            </div>
                            <div class="quantity">
                                <input type="number" value="2" class="form-control form-quantity" />
                            </div>
                            <div class="price">
                                <span class="final h3">₹ 1.998</span>
                                <span class="discount">₹ 2.666</span>
                            </div>
                            <!--delete-this-item-->
                            <span class="icon icon-cross icon-delete"></span>
                        </div>
                        <div class="cart-block cart-block-item clearfix">
                            <div class="image">
                                <a href="product.php"><img src="assets/images/chair3.jpg" alt="" /></a>
                            </div>
                            <div class="title">
                                <div class="h4"><a href="product.php">Green corner</a></div>
                                <div>Green corner</div>
                            </div>
                            <div class="quantity">
                                <input type="number" value="2" class="form-control form-quantity" />
                            </div>
                            <div class="price">
                                <span class="final h3">₹ 1.998</span>
                                <span class="discount">₹ 2.666</span>
                            </div>
                            <!--delete-this-item-->
                            <span class="icon icon-cross icon-delete"></span>
                        </div>
                        <div class="col-md-12" style="padding-top: 2rem;">
                            <div class="form-group">
                                <a href="checkout-1.php" class="btn btn-main" style="float: right;">
                                    <p class="para"><span class="icon icon-chevron-left"></span> checkout</p>
                                </a>
                               
                            </div>

                        </div>

                       
                    </div>
                </div>
            </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/layouts/order.blade.php ENDPATH**/ ?>