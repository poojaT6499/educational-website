

<?php $__env->startSection('content'); ?>

<section></section>

<section class="owl-icons-wrapper">

    <!-- === header === -->

    <header class="hidden">
        <h2>Product categories</h2>
    </header>

    <div class="container">

        <div class="owl-icons">

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-sofa" style="color:#5ec0c2;"></i>
                    <figcaption>Sofa</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-armchair" style="color:#5ec0c2;"></i>
                    <figcaption>Dining </figcaption>
                    Table
                </figure>
            </a>

            <!-- === icon itenter Table= -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-chair" style="color:#5ec0c2;"></i>
                    <figcaption>Chairs</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-dining-table" style="color:#5ec0c2;"></i>
                    <figcaption>Dining tables</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-media-cabinet" style="color:#5ec0c2;"></i>
                    <figcaption>Media storage</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-table" style="color:#5ec0c2;"></i>
                    <figcaption>Tables</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-bookcase" style="color:#5ec0c2;"></i>
                    <figcaption>Bookcase</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-bedroom" style="color:#5ec0c2;"></i>
                    <figcaption>Bedroom</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-nightstand" style="color:#5ec0c2;"></i>
                    <figcaption>Nightstand</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-children-room" style="color:#5ec0c2;"></i>
                    <figcaption>Children room</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-kitchen" style="color:#5ec0c2;"></i>
                    <figcaption>Kitchen</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-bathroom" style="color:#5ec0c2;"></i>
                    <figcaption>Bathroom</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-wardrobe" style="color:#5ec0c2;"></i>
                    <figcaption>Wardrobe</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-shoe-cabinet" style="color:#5ec0c2;"></i>
                    <figcaption>Shoe cabinet</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-office" style="color:#5ec0c2;"></i>
                    <figcaption>Office</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-bar-set" style="color:#5ec0c2;"></i>
                    <figcaption>Bar sets</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-lightning" style="color:#5ec0c2;"></i>
                    <figcaption>Lightning</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-carpet" style="color:#5ec0c2;"></i>
                    <figcaption>Varpet</figcaption>
                </figure>
            </a>

            <!-- === icon item === -->

            <a href="products-grid.php">
                <figure>
                    <i class="f-icon f-icon-accessories" style="color:#5ec0c2;"></i>
                    <figcaption>Accessories</figcaption>
                </figure>
            </a>

        </div>
        <!--/owl-icons-->
    </div>
    <!--/container-->
</section>




<section class="products">

    <div class="container">

        <!-- === header title === -->




        <div class="row ">

            <div class="col-md-9 col-xs-12">
                <div>
                    <div class="wrapper-more bread">
                        <button class="btn btn-main breadbtn" style="width:25%;border-radius: 0px;margin-right: 2px;"
                            href="#bedroom" data-toggle="tab">BEDROOM</button>
                        <button class="btn btn-main breadbtn" style="width:25%;border-radius: 0px;margin-right: 2px;"
                            href="#living" data-toggle="tab">LIVING ROOM
                        </button>
                        <button class="btn btn-main breadbtn" style="width:25%;border-radius: 0px;margin-right: 2px;"
                            href="#dining" data-toggle="tab">DINING ROOM
                        </button>
                        <button class="btn btn-main breadbtn" style="width:25%;border-radius: 0px;margin-right: 2px;"
                            href="#study" data-toggle="tab">STUDY ROOM
                        </button>
                    </div>
                    <div class="tab-content">
                        <!-- === product-item === -->
                        <div id="bedroom" class="tab-pane fade in active">
                            <div class="col-md-4 col-xs-6">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite added">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Green corner</a></h2>
                                            <sub>₹ 1499,-</sub>
                                            <sup>₹ 1099,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-xs-6">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite added">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Green corner</a></h2>
                                            <sub>₹ 1499,-</sub>
                                            <sup>₹ 1099,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-xs-6" style="margin-bottom: 2rem;">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite added">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Green corner</a></h2>
                                            <sub>₹ 1499,-</sub>
                                            <sup>₹ 1099,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        </div>

                        <!-- === product-item === -->
                        <div id="living" class="tab-pane fade in">
                            <div class="col-md-4 col-xs-6">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <!-- <span class="label label-warning">Details</span> -->
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Laura</a></h2>
                                            <sub>₹ 3999,-</sub>
                                            <sup>₹ 3499,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-xs-6">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <!-- <span class="label label-warning">Details</span> -->
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Laura</a></h2>
                                            <sub>₹ 3999,-</sub>
                                            <sup>₹ 3499,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-xs-6" style="margin-bottom: 2rem;">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <!-- <span class="label label-warning">Details</span> -->
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Laura</a></h2>
                                            <sub>₹ 3999,-</sub>
                                            <sup>₹ 3499,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div id="dining" class="tab-pane fade in">
                            <div class="col-md-4 col-xs-6">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <!-- <span class="label label-warning">Details</span> -->
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Aurora</a></h2>
                                            <sub>₹ 3999,-</sub>
                                            <sup>₹ 3499,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-xs-6">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <!-- <span class="label label-warning">Details</span> -->
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Aurora</a></h2>
                                            <sub>₹ 3999,-</sub>
                                            <sup>₹ 3499,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-xs-6" style="margin-bottom: 2rem;">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <!-- <span class="label label-warning">Details</span> -->
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Aurora</a></h2>
                                            <sub>₹ 3999,-</sub>
                                            <sup>₹ 3499,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div id="study" class="tab-pane fade in">
                            <div class="col-md-4 col-xs-6">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <!-- <span class="label label-warning">Details</span> -->
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Dining set</a></h2>
                                            <sub>₹ 3999,-</sub>
                                            <sup>₹ 3499,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-xs-6">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <!-- <span class="label label-warning">Details</span> -->
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Dining set</a></h2>
                                            <sub>₹ 3999,-</sub>
                                            <sup>₹ 3499,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-xs-6" style="margin-bottom: 2rem;">
                                <article>
                                    <div class="info">
                                        <span class="add-favorite">
                                            <a href="javascript:void(0);" data-title="Add to favorites"
                                                data-title-added="Added to favorites list"><i
                                                    class="icon icon-heart"></i></a>
                                        </span>
                                        <span>
                                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                                    class="icon icon-eye"></i></a>
                                        </span>
                                        <span>
                                            <a href="product.php" class="" data-title="Details"><i
                                                    class="fa fa-book" aria-hidden="true"></i></a>
                                        </span>
                                    </div>
                                    <div class="btn btn-add">
                                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                                    </div>
                                    <div id="toast">
                                        <div class="checkicon"> <i class="fa fa-check-circle-o"
                                                aria-hidden="true" style="color:green;"></i> </div>
                                        Item added successfully in cart!
                                    </div>
                                    <div class="figure-grid">
                                        <!-- <span class="label label-warning">Details</span> -->
                                        <div class="image">
                                            <a href="product.php" class="">
                                                <img src="assets/images/chair.jpg" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="product.php">Dining set</a></h2>
                                            <sub>₹ 3999,-</sub>
                                            <sup>₹ 3499,-</sup>
                                            <span class="description clearfix">Gubergren amet dolor ea diam
                                                takimata
                                                consetetur
                                                facilisis blandit et aliquyam lorem ea duo labore diam sit et
                                                consetetur
                                                nulla</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="accord">
                        <button class="accordion"><strong>Important Terms</strong>
                        </button>

                        <div class="panel">

                            <div class="container" style="margin-top: 1rem;">
                                <div class="row">
                                    <div class="col-md-6 col-xs-6" style="display: flex;align-items: baseline">
                                        <div>
                                            <img src="assets/images/delivery-truck.png" hight="10px"
                                                width="30px">
                                        </div>
                                        <div>
                                            <h6>Free delivery and setup</h6>
                                        </div>

                                    </div>
                                    <!-- <div class="col-md-4 col-xs-6">
                                    <h6>100% refund if you are unhappy with the furniture.</h6>
                                </div> -->
                                    <div class="col-md-6 col-xs-6" style="display: flex;align-items: baseline">
                                        <div>
                                            <img src="assets/images/money-back.png" hight="10px" width="30px">
                                        </div>
                                        <div>
                                            <h6>100% refund if you are unhappy with the furniture.</h6>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <h4>RentoFurnish Benefits</h4>
                                <div class="margin-tb-l">

                                    <div class="row" style="margin-bottom:3rem;">
                                        <div class="col-md-4 ">
                                            <div class="form-group">
                                                <div class="container bg-white h-100 benefit-container">
                                                    <div
                                                        class="row bg-primary padding-tb-l padding-rl-m align-items-center pop2">
                                                        <div class="col-md-2  padding-l-m">
                                                            <!-- <i class="fa fa-map-marker" aria-hidden="true"></i> -->
                                                            <img src="assets/images/spray.png" class="s-30">
                                                        </div>
                                                        <div
                                                            class="col-md-10  padding-l-l font-color-snow font-size-16 font-weight-light">
                                                            <!-- <img src="assets/images/destination.png" class="s-30"> -->
                                                            Cleaning Services
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col font-weight-light padding-tb-l pop1">
                                                            Don't
                                                            fret about cleaning furniture surfaces and
                                                            upholstery!
                                                            You get a free deep cleaning every 6 months.</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 ">
                                            <div class="form-group">
                                                <div class="container bg-white h-100 benefit-container">
                                                    <div
                                                        class="row bg-primary padding-tb-l padding-rl-m align-items-center pop2">
                                                        <div class="col-md-2  padding-l-m">
                                                            <img src="assets/images/protection1.png"
                                                                class="s-30">
                                                        </div>
                                                        <div
                                                            class="col-md-10  padding-l-l font-color-snow font-size-16 font-weight-light">
                                                            <!-- <img src="assets/images/protection1.png" class="s-30"> -->
                                                            Damage Waiver
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col font-weight-light padding-tb-l pop1">It
                                                            is
                                                            natural to have some wear and tear during the course
                                                            of
                                                            your subscription. The good news is we have you
                                                            covered
                                                            for damages of up to Rs. 10,000.</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 ">
                                            <div class="form-group">
                                                <div class="container bg-white h-100 benefit-container">
                                                    <div
                                                        class="row bg-primary padding-tb-l padding-rl-m align-items-center pop2">
                                                        <div class="col-md-2  padding-l-m">
                                                            <img src="assets/images/destination.png"
                                                                class="s-30">
                                                            <!-- <i class="fa fa-star-o" aria-hidden="true"></i> -->
                                                        </div>
                                                        <div
                                                            class="col-md-10  padding-l-l font-color-snow font-size-16 font-weight-light">
                                                            <!-- <img src="assets/images/medal.png" class="s-30"> -->
                                                            Free Relocation

                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col font-weight-light padding-tb-l pop1">
                                                            Moving
                                                            homes? Not to worry. We will relocate your Furlenco
                                                            furniture for free once a year between and across
                                                            the
                                                            cities we service.</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="wrapper-more">
                                    <a href="" class="btn btn-main">
                                        <p style="margin: 1rem;">okay</p>
                                    </a>
                                </div> -->

                            </div>

                        </div>
                    </div>
                    <div class="accord">
                        <button class="accordion"><strong>How it works</strong>
                        </button>

                        <div class="panel">

                            <div class="container" style="margin-top: 1rem;">
                            <div class="tile-package-variants">
                                <ul class="">

                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Choose the room you want to
                                                furnish (Bed Room, Living Room, Dining Room, Study Room)</span>
                                        </div>
                                    </li>

                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Browse through the range of
                                                Core Furniture and add at least 1 item</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Explore our Soft Furnishing range to add a dash of color
                                                (optional)</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Accessorize your room from our Appliances section
                                                (optional)</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Something missing? Check out the range of Other Furniture
                                                (optional)</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Check out!</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>



                            </div>

                        </div>
                    </div>

                </div>



                <!-- <div class="wrapper-more">
                    <a href="products-grid.php" class=" btn btn-main plan-pro">
                        <p style="margin: 1rem;">View store</p>
                    </a>

                </div> -->

            </div>

            <div class="col-md-3 col-xs-12 ">
                <div class="plan1">
                    <article>
                        <div class="card ">
                            <div class="card-body" style="padding: 2rem;">
                                <div class="wrapper-more">
                                    <h4 class="card-title">summary </h4>
                                    <h6>Total Rental Amount</h6>
                                    <span class="final h3">₹ 1.998/<small>month</small></span>
                                    <h6>(Inclusive of delivery and assembly)</h6>
                                </div>
                                <div class="wrapper-more">
                                    <a href="plans-checkout.php" class="btn btn-main">
                                        <p style="margin: 1rem;">Checkout</p>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
                <div class="plan1">
                    <article>
                        <div class="card ">
                            <div class="card-body" style="padding: 2rem;">
                                <h6>Core Furniture</h6>
                                <div class="clearfix">
                                    <div class="cart-block cart-block-item clearfix">
                                        <div class="row">
                                            <div class="col-md-7 col-xs-8">
                                                <div class="">
                                                    <div class="h6"><a href="product.php">Dinning Set</a><br>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-5 col-xs-4" style="display:flex;">
                                                <div class="price" style="margin-right: 2rem;">
                                                    <span class="final h6">₹ 1.998</span>
                                                </div>
                                                <span class="icon icon-cross icon-delete"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="cart-block cart-block-item clearfix">
                                        <div class="row">
                                            <div class="col-md-7 col-xs-8">
                                                <div class="">
                                                    <div class="h6"><a href="product.php">Dinning Set</a><br>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-5 col-xs-4" style="display:flex;">
                                                <div class="price" style="margin-right: 2rem;">
                                                    <span class="final h6">₹ 1.998</span>
                                                </div>
                                                <span class="icon icon-cross icon-delete"></span>
                                            </div>
                                        </div>
                                    </div>

                                </div>


                            </div>
                        </div>
                    </article>
                </div>
                <!-- <div class="wrapper-more">

                    <button href="#terms" class="btn btn-main mfp-open"
                        style="width: 346px; border-radius: 0px;">
                        <p>Important Terms</p>
                    </button>

                </div> -->
                <!-- <div class="wrapper-more">

                    <button href="#works" class="btn btn-main mfp-open"
                        style="width: 346px; border-radius: 0px;">
                        <p>How it works</p>
                    </button>

                </div> -->
                <div class="wrapper-more">

                    <button href="#reset" class="btn btn-main mfp-open"
                        style="width: 346px; border-radius: 0px;">
                        <p>Reset</p>
                    </button>

                </div>
            </div>

        </div>
        <!--/row-->
        <!-- === button more === -->
        <!-- ========================  Product info popup - quick view ======================== -->
        <div class="popup-main mfp-hide" id="productid1">

            <!-- === product popup === -->

            <div class="product">

                <!-- === popup-title === -->

                <div class="popup-title">
                    <div class="h1 title">Laura <small>product category</small></div>
                </div>

                <!-- === product gallery === -->

                <div class="owl-product-gallery">
                    <img src="assets/images/sofa.jpg" alt="" height="640" />
                    <img src="assets/images/sofa.jpg" alt="" height="640" />
                    <img src="assets/images/sofa.jpg" alt="" height="640" />
                    <img src="assets/images/sofa.jpg" alt="" height="640" />
                </div>

                <!-- === product-popup-info === -->

                <div class="popup-content">
                    <div class="product-info-wrapper">
                        <div class="container">
                            <div class="tile-package-variants">
                            </div>
                            <div class="basic" style="margin-left: 15rem;">
                                <button class="tablinks btn btn-main" onclick="openCity(event, 'product')"
                                    id="basicBtn">Basic</button>
                                <button class="tablinks btn btn-main"
                                    onclick="openCity(event, 'product1')">Primium</button>

                            </div>
                            <div id="product" class="tabcontent">
                                <div class="tile-items d-flex flex-column">
                                    <div class="tile-items-heading">2 ITEMS</div>
                                    <div class="d-flex">
                                        <div
                                            class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                            <div
                                                class="item-oval d-flex justify-content-center align-items-center">
                                                <img src="//d24xw9xsv7y3uu.cloudfront.net/new-uploads/production/items/1064/mobile/IDm8ciaO___FUR7920_4.jpg"
                                                    itemprop="image" width="100%">
                                            </div>
                                            <div class="">
                                                <!-- <span>1 unit</span> -->
                                            </div>
                                        </div>
                                        <div
                                            class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                            <div
                                                class="item-oval d-flex justify-content-center align-items-center">
                                                <img src="//d24xw9xsv7y3uu.cloudfront.net/new-uploads/production/items/681/mobile/vWEVFYzZ__Mili Queen Bed (1).jpg"
                                                    itemprop="image" width="100%"></div>
                                            <div class="">
                                                <!-- <span>1 unit</span> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div id="product1" class="tabcontent">
                                <div class=" tile-items d-flex flex-column">
                                    <div class="tile-items-heading">3 ITEMS</div>
                                    <div class="d-flex">
                                        <div
                                            class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                            <div
                                                class="item-oval d-flex justify-content-center align-items-center">
                                                <img src="//d24xw9xsv7y3uu.cloudfront.net/new-uploads/production/items/681/mobile/vWEVFYzZ__Mili Queen Bed (1).jpg"
                                                    itemprop="image" width="100%"></div>
                                            <div class="">
                                                <!-- <span>1 unit</span> -->
                                            </div>
                                        </div>
                                        <div
                                            class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                            <div
                                                class="item-oval d-flex justify-content-center align-items-center">
                                                <img src="//d24xw9xsv7y3uu.cloudfront.net/new-uploads/production/items/1064/mobile/IDm8ciaO___FUR7920_4.jpg"
                                                    itemprop="image" width="100%"></div>
                                            <div class="">
                                                <!-- <span>1 unit</span> -->
                                            </div>
                                        </div>
                                        <div
                                            class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                            <div
                                                class="item-oval d-flex justify-content-center align-items-center">
                                                <img src="//d26iwjla857pn6.cloudfront.net/uploads/production/furniture_item/11/1440w_4224a6ff.jpg"
                                                    itemprop="image" width="100%"></div>
                                            <div class="">
                                                <!-- <span>1 unit</span></div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <!--/row-->
                    </div>
                    <!--/product-info-wrapper-->
                </div>
                <!--/popup-content-->
                <!-- === product-popup-footer === -->

                <div class="popup-table">
                    <div class="popup-cell">
                        <div class="price">
                            <span class="h3">₹ 1999,00 <small>₹ 2999,00</small></span>
                        </div>
                    </div>
                    <div class="popup-cell">
                        <div class="popup-buttons">
                            <a href="product.php"><span class="icon icon-eye"></span> <span
                                    class="hidden-xs">View more</span></a>
                            <a href="javascript:void(0);"><span class="icon icon-cart"></span> <span
                                    class="hidden-xs">Rent</span></a>
                        </div>
                    </div>
                </div>

            </div>



            <!--popup-main-->
        </div>

        <div class="popup-main mfp-hide" id="terms">

            <!-- === product popup === -->

            <div class="product">

                <!-- === popup-title === -->

                <div class="popup-title">
                    <div class="h1 title">Important Terms </div>
                </div>



                <div class="popup-content">
                    <div class="product-info-wrapper">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-4 col-xs-6" style="display: flex;">
                                    <div>
                                        <img src="assets/images/delivery-truck.png" hight="10px" width="30px">
                                    </div>
                                    <div>
                                        <h6>Free delivery and setup</h6>
                                    </div>

                                </div>
                                <!-- <div class="col-md-4 col-xs-6">
                                    <h6>100% refund if you are unhappy with the furniture.</h6>
                                </div> -->
                                <div class="col-md-8 col-xs-6" style="display: flex;">
                                    <div>
                                        <img src="assets/images/money-back.png" hight="10px" width="30px">
                                    </div>
                                    <div>
                                        <h6>100% refund if you are unhappy with the furniture.</h6>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <h4>RentoFurnish Benefits</h4>
                            <div class="margin-tb-l">

                                <div class="row" style="margin-bottom:3rem;">
                                    <div class="col-md-4 ">
                                        <div class="form-group">
                                            <div class="container bg-white h-100 benefit-container">
                                                <div
                                                    class="row bg-primary padding-tb-l padding-rl-m align-items-center pop2">
                                                    <div class="col-md-2  padding-l-m">
                                                        <!-- <i class="fa fa-map-marker" aria-hidden="true"></i> -->
                                                        <img src="assets/images/spray.png" class="s-30">
                                                    </div>
                                                    <div
                                                        class="col-md-10  padding-l-l font-color-snow font-size-16 font-weight-light">
                                                        <!-- <img src="assets/images/destination.png" class="s-30"> -->
                                                        Cleaning Services
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col font-weight-light padding-tb-l pop1">Don't
                                                        fret about cleaning furniture surfaces and upholstery!
                                                        You get a free deep cleaning every 6 months.</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 ">
                                        <div class="form-group">
                                            <div class="container bg-white h-100 benefit-container">
                                                <div
                                                    class="row bg-primary padding-tb-l padding-rl-m align-items-center pop2">
                                                    <div class="col-md-2  padding-l-m">
                                                        <img src="assets/images/protection1.png" class="s-30">
                                                    </div>
                                                    <div
                                                        class="col-md-10  padding-l-l font-color-snow font-size-16 font-weight-light">
                                                        <!-- <img src="assets/images/protection1.png" class="s-30"> -->
                                                        Damage Waiver
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col font-weight-light padding-tb-l pop1">It is
                                                        natural to have some wear and tear during the course of
                                                        your subscription. The good news is we have you covered
                                                        for damages of up to Rs. 10,000.</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 ">
                                        <div class="form-group">
                                            <div class="container bg-white h-100 benefit-container">
                                                <div
                                                    class="row bg-primary padding-tb-l padding-rl-m align-items-center pop2">
                                                    <div class="col-md-2  padding-l-m">
                                                        <img src="assets/images/destination.png" class="s-30">
                                                        <!-- <i class="fa fa-star-o" aria-hidden="true"></i> -->
                                                    </div>
                                                    <div
                                                        class="col-md-10  padding-l-l font-color-snow font-size-16 font-weight-light">
                                                        <!-- <img src="assets/images/medal.png" class="s-30"> -->
                                                        Free Relocation

                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col font-weight-light padding-tb-l pop1">Moving
                                                        homes? Not to worry. We will relocate your Furlenco
                                                        furniture for free once a year between and across the
                                                        cities we service.</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="wrapper-more">
                                <a href="" class="btn btn-main">
                                    <p style="margin: 1rem;">okay</p>
                                </a>
                            </div>

                        </div>
                        <!--/row-->
                    </div>
                    <!--/product-info-wrapper-->
                </div>
                <!--/popup-content-->
                <!-- === product-popup-footer === -->



            </div>


        </div>






        <div class="popup-main mfp-hide" id="works">

            <!-- === product popup === -->

            <div class="product">

                <!-- === popup-title === -->

                <div class="popup-title">
                    <div class="h4 title">How It Works</div>
                </div>

                <!-- === product gallery === -->

                <div class="owl-product-gallery">
                    <!-- <img src="assets/images/sofa.jpg" alt="" height="640" />
                    <img src="assets/images/sofa.jpg" alt="" height="640" />
                    <img src="assets/images/sofa.jpg" alt="" height="640" />
                    <img src="assets/images/sofa.jpg" alt="" height="640" /> -->
                </div>

                <!-- === product-popup-info === -->

                <div class="popup-content">
                    <div class="product-info-wrapper">
                        <!-- <div class="container">
                            <div class="tile-package-variants">
                                <ul class="">

                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Choose the room you want to
                                                furnish (Bed Room, Living Room, Dining Room, Study Room)</span>
                                        </div>
                                    </li>

                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Browse through the range of
                                                Core Furniture and add at least 1 item</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Explore our Soft Furnishing range to add a dash of color
                                                (optional)</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Accessorize your room from our Appliances section
                                                (optional)</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Something missing? Check out the range of Other Furniture
                                                (optional)</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Check out!</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>


                        </div> -->
                        <div class="container">
                            <div class="tile-package-variants">
                                <ul class="">

                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Choose the room you want to
                                                furnish (Bed Room, Living Room, Dining Room, Study Room)</span>
                                        </div>
                                    </li>

                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Browse through the range of
                                                Core Furniture and add at least 1 item</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Explore our Soft Furnishing range to add a dash of color
                                                (optional)</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Accessorize your room from our Appliances section
                                                (optional)</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Something missing? Check out the range of Other Furniture
                                                (optional)</span>
                                        </div>
                                    </li>
                                    <li class=" padding-l-m dis">
                                        <div class="mar1">
                                            <i class="fa fa-check-circle check" aria-hidden="true"></i>
                                        </div>
                                        <div>
                                            <span>Check out!</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>


                        </div>
                        <!--/row-->
                    </div>
                    <!--/product-info-wrapper-->
                </div>
            </div>
            <!--/popup-content-->
            <!-- === product-popup-footer === -->



        </div>
        <div class="popup-main mfp-hide" id="reset">



            <div class="product">
                <div class="popup-content">
                    <div class="product-info-wrapper">
                        <div class="container">
                            <div class="tile-package-variants">
                                <h6>Are you sure you want to reset your package?</h6>
                            </div>
                            <div>
                                <button type="" class="basic btn btn-main">yes </button>
                                <button type="" class=" btn btn-main">No</button>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

        </div>
</div>
</section>



<script>
    var acc = document.getElementsByClassName("accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function () {
            this.classList.toggle("active1");
            var panel = this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            }
        });
    }
</script>

<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();
</script>

<script>
    function toastFunction() {
        var x = document.getElementById("toast");
        x.className = "show";
        setTimeout(function () {
            x.className = x.className.replace("show", "");
        }, 3000);
    }
</script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/layouts/customize.blade.php ENDPATH**/ ?>