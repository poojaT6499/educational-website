

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <div class="row page-titles mx-0">
      <div class="col-sm-6 p-md-0">
          <div class="welcome-text">
              <h4>All Professors</h4>
          </div>
      </div>
      <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.html">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(Request::root()); ?>/admin/category">Category</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(Request::root()); ?>/admin/category/add-category">Add Category</a></li>
          </ol>
      </div>
  </div>
  <div class="row">
      <div class="col-lg-12">
          <ul class="nav nav-pills mb-3">
              <li class="nav-item"><a href="#list-view" data-toggle="tab"
                      class="nav-link btn-primary mr-1 show active">List View</a></li>
              <li class="nav-item"><a href="#grid-view" data-toggle="tab"
                      class="nav-link btn-primary">Grid View</a></li>
          </ul>
      </div>
      <div class="col-lg-12">
          <div class="row tab-content">
              <div id="list-view" class="tab-pane fade active show col-lg-12">
                  <div class="card">
                      <div class="card-header">
                          <h4 class="card-title">All Professors </h4>
                          <a href="<?php echo e(Request::root()); ?>/admin/category/add-category" class="btn btn-primary">+ Add new</a>
                      </div>
                      <div class="card-body">
                          <div class="table-responsive">
                              <table id="example3" class="display" style="min-width: 845px">
                                  <thead>
                                      <tr>
                                          <th></th>
                                          <th>Name</th>
                                          <th>Department</th>
                                          <th>Gender</th>
                                          <th>Education</th>
                                          <th>Mobile</th>
                                          <th>Email</th>
                                          <th>Joining Date</th>
                                          <th>Action</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                      <tr>
                                          <td><img class="rounded-circle" width="35"
                                                  src="images/profile/small/pic1.jpg" alt=""></td>
                                          <td>Tiger Nixon</td>
                                          <td>Architect</td>
                                          <td>Male</td>
                                          <td>M.COM., P.H.D.</td>
                                          <td><a href="javascript:void(0);"><strong>123 456
                                                      7890</strong></a></td>
                                          <td><a href="javascript:void(0);"><strong><span
                                                          class="__cf_email__"
                                                          data-cfemail="b3daddd5dcf3d6cbd2dec3dfd69dd0dcde">[email&#160;protected]</span></strong></a>
                                          </td>
                                          <td>2011/04/25</td>
                                          <td>
                                              <a href="javascript:void(0);"
                                                  class="btn btn-sm btn-primary"><i
                                                      class="la la-pencil"></i></a>
                                              <a href="javascript:void(0);"
                                                  class="btn btn-sm btn-danger"><i
                                                      class="la la-trash-o"></i></a>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td><img class="rounded-circle" width="35"
                                                  src="images/profile/small/pic2.jpg" alt=""></td>
                                          <td>Garrett Winters</td>
                                          <td>Accountant</td>
                                          <td>Female</td>
                                          <td>M.COM., P.H.D.</td>
                                          <td><a href="javascript:void(0);"><strong>987 654
                                                      3210</strong></a></td>
                                          <td><a href="javascript:void(0);"><strong><span
                                                          class="__cf_email__"
                                                          data-cfemail="f39a9d959cb3968b929e839f96dd909c9e">[email&#160;protected]</span></strong></a>
                                          </td>
                                          <td>2011/07/25</td>
                                          <td>
                                              <a href="javascript:void(0);"
                                                  class="btn btn-sm btn-primary"><i
                                                      class="la la-pencil"></i></a>
                                              <a href="javascript:void(0);"
                                                  class="btn btn-sm btn-danger"><i
                                                      class="la la-trash-o"></i></a>
                                          </td>
                                      </tr>
                                  
                                  </tbody>
                              </table>
                          </div>
                      </div>
                  </div>
              </div>
              <div id="grid-view" class="tab-pane fade col-lg-12">
                  <div class="row">
                      <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                          <div class="card card-profile">
                              <div class="card-header justify-content-end pb-0">
                                  <div class="dropdown">
                                      <button class="btn btn-link" type="button" data-toggle="dropdown">
                                          <span class="dropdown-dots fs--1"></span>
                                      </button>
                                      <div class="dropdown-menu dropdown-menu-right border py-0">
                                          <div class="py-2">
                                              <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                              <a class="dropdown-item text-danger"
                                                  href="javascript:void(0);">Delete</a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card-body pt-2">
                                  <div class="text-center">
                                      <div class="profile-photo">
                                          <img src="images/profile/small/pic2.jpg" width="100"
                                              class="img-fluid rounded-circle" alt="">
                                      </div>
                                      <h3 class="mt-4 mb-1">Alexander</h3>
                                      <p class="text-muted">M.COM., P.H.D.</p>
                                      <ul class="list-group mb-3 list-group-flush">
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Gender :</span><strong>Male</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Phone No. :</span><strong>+01 123 456
                                                  7890</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Email:</span><strong><a
                                                      href="/cdn-cgi/l/email-protection"
                                                      class="__cf_email__"
                                                      data-cfemail="224b4c444d62475a434f524e470c414d4f">[email&#160;protected]</a></strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Address:</span><strong>#8901 Marmora
                                                  Road</strong></li>
                                      </ul>
                                      <a class="btn btn-outline-primary btn-rounded mt-3 px-4"
                                          href="professor-profile.html">Read More</a>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                          <div class="card card-profile">
                              <div class="card-header justify-content-end pb-0">
                                  <div class="dropdown">
                                      <button class="btn btn-link" type="button" data-toggle="dropdown">
                                          <span class="dropdown-dots fs--1"></span>
                                      </button>
                                      <div class="dropdown-menu dropdown-menu-right border py-0">
                                          <div class="py-2">
                                              <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                              <a class="dropdown-item text-danger"
                                                  href="javascript:void(0);">Delete</a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card-body pt-2">
                                  <div class="text-center">
                                      <div class="profile-photo">
                                          <img src="images/profile/small/pic3.jpg" width="100"
                                              class="img-fluid rounded-circle" alt="">
                                      </div>
                                      <h3 class="mt-4 mb-1">Elizabeth</h3>
                                      <p class="text-muted">B.COM., M.COM.</p>
                                      <ul class="list-group mb-3 list-group-flush">
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Gender :</span><strong>Female</strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Phone No. :</span><strong>+01 123 456
                                                  7890</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Email:</span><strong><a
                                                      href="/cdn-cgi/l/email-protection"
                                                      class="__cf_email__"
                                                      data-cfemail="7c15121a133c19041d110c1019521f1311">[email&#160;protected]</a></strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Address:</span><strong>#8901 Marmora
                                                  Road</strong></li>
                                      </ul>
                                      <a class="btn btn-outline-primary btn-rounded mt-3 px-4"
                                          href="professor-profile.html">Read More</a>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                          <div class="card card-profile">
                              <div class="card-header justify-content-end pb-0">
                                  <div class="dropdown">
                                      <button class="btn btn-link" type="button" data-toggle="dropdown">
                                          <span class="dropdown-dots fs--1"></span>
                                      </button>
                                      <div class="dropdown-menu dropdown-menu-right border py-0">
                                          <div class="py-2">
                                              <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                              <a class="dropdown-item text-danger"
                                                  href="javascript:void(0);">Delete</a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card-body pt-2">
                                  <div class="text-center">
                                      <div class="profile-photo">
                                          <img src="images/profile/small/pic4.jpg" width="100"
                                              class="img-fluid rounded-circle" alt="">
                                      </div>
                                      <h3 class="mt-4 mb-1">Amelia</h3>
                                      <p class="text-muted">M.COM., P.H.D.</p>
                                      <ul class="list-group mb-3 list-group-flush">
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Gender :</span><strong>Female</strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Phone No. :</span><strong>+01 123 456
                                                  7890</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Email:</span><strong><a
                                                      href="/cdn-cgi/l/email-protection"
                                                      class="__cf_email__"
                                                      data-cfemail="3f565159507f5a475e524f535a115c5052">[email&#160;protected]</a></strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Address:</span><strong>#8901 Marmora
                                                  Road</strong></li>
                                      </ul>
                                      <a class="btn btn-outline-primary btn-rounded mt-3 px-4"
                                          href="professor-profile.html">Read More</a>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                          <div class="card card-profile">
                              <div class="card-header justify-content-end pb-0">
                                  <div class="dropdown">
                                      <button class="btn btn-link" type="button" data-toggle="dropdown">
                                          <span class="dropdown-dots fs--1"></span>
                                      </button>
                                      <div class="dropdown-menu dropdown-menu-right border py-0">
                                          <div class="py-2">
                                              <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                              <a class="dropdown-item text-danger"
                                                  href="javascript:void(0);">Delete</a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card-body pt-2">
                                  <div class="text-center">
                                      <div class="profile-photo">
                                          <img src="images/profile/small/pic5.jpg" width="100"
                                              class="img-fluid rounded-circle" alt="">
                                      </div>
                                      <h3 class="mt-4 mb-1">Charlotte</h3>
                                      <p class="text-muted">B.COM., M.COM.</p>
                                      <ul class="list-group mb-3 list-group-flush">
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Gender :</span><strong>Female</strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Phone No. :</span><strong>+01 123 456
                                                  7890</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Email:</span><strong><a
                                                      href="/cdn-cgi/l/email-protection"
                                                      class="__cf_email__"
                                                      data-cfemail="6d04030b022d08150c001d0108430e0200">[email&#160;protected]</a></strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Address:</span><strong>#8901 Marmora
                                                  Road</strong></li>
                                      </ul>
                                      <a class="btn btn-outline-primary btn-rounded mt-3 px-4"
                                          href="professor-profile.html">Read More</a>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                          <div class="card card-profile">
                              <div class="card-header justify-content-end pb-0">
                                  <div class="dropdown">
                                      <button class="btn btn-link" type="button" data-toggle="dropdown">
                                          <span class="dropdown-dots fs--1"></span>
                                      </button>
                                      <div class="dropdown-menu dropdown-menu-right border py-0">
                                          <div class="py-2">
                                              <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                              <a class="dropdown-item text-danger"
                                                  href="javascript:void(0);">Delete</a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card-body pt-2">
                                  <div class="text-center">
                                      <div class="profile-photo">
                                          <img src="images/profile/small/pic6.jpg" width="100"
                                              class="img-fluid rounded-circle" alt="">
                                      </div>
                                      <h3 class="mt-4 mb-1">Isabella</h3>
                                      <p class="text-muted">B.A, B.C.A</p>
                                      <ul class="list-group mb-3 list-group-flush">
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Gender :</span><strong>Female</strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Phone No. :</span><strong>+01 123 456
                                                  7890</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Email:</span><strong><a
                                                      href="/cdn-cgi/l/email-protection"
                                                      class="__cf_email__"
                                                      data-cfemail="30595e565f705548515d405c551e535f5d">[email&#160;protected]</a></strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Address:</span><strong>#8901 Marmora
                                                  Road</strong></li>
                                      </ul>
                                      <a class="btn btn-outline-primary btn-rounded mt-3 px-4"
                                          href="professor-profile.html">Read More</a>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                          <div class="card card-profile">
                              <div class="card-header justify-content-end pb-0">
                                  <div class="dropdown">
                                      <button class="btn btn-link" type="button" data-toggle="dropdown">
                                          <span class="dropdown-dots fs--1"></span>
                                      </button>
                                      <div class="dropdown-menu dropdown-menu-right border py-0">
                                          <div class="py-2">
                                              <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                              <a class="dropdown-item text-danger"
                                                  href="javascript:void(0);">Delete</a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card-body pt-2">
                                  <div class="text-center">
                                      <div class="profile-photo">
                                          <img src="images/profile/small/pic7.jpg" width="100"
                                              class="img-fluid rounded-circle" alt="">
                                      </div>
                                      <h3 class="mt-4 mb-1">Sebastian</h3>
                                      <p class="text-muted">M.COM., P.H.D.</p>
                                      <ul class="list-group mb-3 list-group-flush">
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Gender :</span><strong>Male</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Phone No. :</span><strong>+01 123 456
                                                  7890</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Email:</span><strong><a
                                                      href="/cdn-cgi/l/email-protection"
                                                      class="__cf_email__"
                                                      data-cfemail="82ebece4edc2e7fae3eff2eee7ace1edef">[email&#160;protected]</a></strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Address:</span><strong>#8901 Marmora
                                                  Road</strong></li>
                                      </ul>
                                      <a class="btn btn-outline-primary btn-rounded mt-3 px-4"
                                          href="professor-profile.html">Read More</a>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                          <div class="card card-profile">
                              <div class="card-header justify-content-end pb-0">
                                  <div class="dropdown">
                                      <button class="btn btn-link" type="button" data-toggle="dropdown">
                                          <span class="dropdown-dots fs--1"></span>
                                      </button>
                                      <div class="dropdown-menu dropdown-menu-right border py-0">
                                          <div class="py-2">
                                              <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                              <a class="dropdown-item text-danger"
                                                  href="javascript:void(0);">Delete</a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card-body pt-2">
                                  <div class="text-center">
                                      <div class="profile-photo">
                                          <img src="images/profile/small/pic8.jpg" width="100"
                                              class="img-fluid rounded-circle" alt="">
                                      </div>
                                      <h3 class="mt-4 mb-1">Olivia</h3>
                                      <p class="text-muted">B.COM., M.COM.</p>
                                      <ul class="list-group mb-3 list-group-flush">
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Gender :</span><strong>Female</strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Phone No. :</span><strong>+01 123 456
                                                  7890</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Email:</span><strong><a
                                                      href="/cdn-cgi/l/email-protection"
                                                      class="__cf_email__"
                                                      data-cfemail="630a0d050c23061b020e130f064d000c0e">[email&#160;protected]</a></strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Address:</span><strong>#8901 Marmora
                                                  Road</strong></li>
                                      </ul>
                                      <a class="btn btn-outline-primary btn-rounded mt-3 px-4"
                                          href="professor-profile.html">Read More</a>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                          <div class="card card-profile">
                              <div class="card-header justify-content-end pb-0">
                                  <div class="dropdown">
                                      <button class="btn btn-link" type="button" data-toggle="dropdown">
                                          <span class="dropdown-dots fs--1"></span>
                                      </button>
                                      <div class="dropdown-menu dropdown-menu-right border py-0">
                                          <div class="py-2">
                                              <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                              <a class="dropdown-item text-danger"
                                                  href="javascript:void(0);">Delete</a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card-body pt-2">
                                  <div class="text-center">
                                      <div class="profile-photo">
                                          <img src="images/profile/small/pic9.jpg" width="100"
                                              class="img-fluid rounded-circle" alt="">
                                      </div>
                                      <h3 class="mt-4 mb-1">Emma</h3>
                                      <p class="text-muted">B.A, B.C.A</p>
                                      <ul class="list-group mb-3 list-group-flush">
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Gender :</span><strong>Female</strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Phone No. :</span><strong>+01 123 456
                                                  7890</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Email:</span><strong><a
                                                      href="/cdn-cgi/l/email-protection"
                                                      class="__cf_email__"
                                                      data-cfemail="365f58505976534e575b465a531855595b">[email&#160;protected]</a></strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Address:</span><strong>#8901 Marmora
                                                  Road</strong></li>
                                      </ul>
                                      <a class="btn btn-outline-primary btn-rounded mt-3 px-4"
                                          href="professor-profile.html">Read More</a>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                          <div class="card card-profile">
                              <div class="card-header justify-content-end pb-0">
                                  <div class="dropdown">
                                      <button class="btn btn-link" type="button" data-toggle="dropdown">
                                          <span class="dropdown-dots fs--1"></span>
                                      </button>
                                      <div class="dropdown-menu dropdown-menu-right border py-0">
                                          <div class="py-2">
                                              <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                              <a class="dropdown-item text-danger"
                                                  href="javascript:void(0);">Delete</a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card-body pt-2">
                                  <div class="text-center">
                                      <div class="profile-photo">
                                          <img src="images/profile/small/pic10.jpg" width="100"
                                              class="img-fluid rounded-circle" alt="">
                                      </div>
                                      <h3 class="mt-4 mb-1">Jackson</h3>
                                      <p class="text-muted">M.COM., P.H.D.</p>
                                      <ul class="list-group mb-3 list-group-flush">
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Gender :</span><strong>Male</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Phone No. :</span><strong>+01 123 456
                                                  7890</strong></li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Email:</span><strong><a
                                                      href="/cdn-cgi/l/email-protection"
                                                      class="__cf_email__"
                                                      data-cfemail="224b4c444d62475a434f524e470c414d4f">[email&#160;protected]</a></strong>
                                          </li>
                                          <li class="list-group-item px-0 d-flex justify-content-between">
                                              <span class="mb-0">Address:</span><strong>#8901 Marmora
                                                  Road</strong></li>
                                      </ul>
                                      <a class="btn btn-outline-primary btn-rounded mt-3 px-4"
                                          href="professor-profile.html">Read More</a>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\learningApp\resources\views/admin/category/index.blade.php ENDPATH**/ ?>