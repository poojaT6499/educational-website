

<?php $__env->startSection('content'); ?>

<section class="main-header" style="background-image:url(assets/images/productbanner.jpg);opacity:0.8;">
    <header>
        <div class="container text-center">
            <h2 class="h2 title">Checkout</h2>
            <ol class="breadcrumb breadcrumb-inverted">
                <li><a href="index.php"><span class="icon icon-home"></span></a></li>
                <li><a href="checkout-1.php">Cart items</a></li>
                <li><a class="active" href="checkout-2.php">Delivery</a></li>
                <!-- <li><a href="checkout-3.php">Payment</a></li>
                <li><a href="checkout-4.php">Receipt</a></li> -->
            </ol>
        </div>
    </header>
</section>

<!-- ========================  Step wrapper ======================== -->

<!-- ========================  Checkout ======================== -->

<section class="checkout">
    <div class="container">

        <header class="hidden">
            <h3 class="h3 title">Checkout - Step 2</h3>
        </header>

        <!-- ========================  Cart navigation ======================== -->

        <div class="clearfix">
            <div class="row">
                <div class="col-xs-6">
                    <a href="profile.php" class="btn btn-main" style="width: 14rem;">
                        <p class="para"><span class="icon icon-chevron-left"></span> Back to cart</p>
                    </a>
                </div>
                <div class="col-xs-6 text-right">
                    <a href="#" class="btn btn-main" style="width: 19rem;">
                        <p class="para"><span class="icon icon-cart"></span> Go to payment</p>
                    </a>
                </div>
            </div>
        </div>

        <!-- ========================  Delivery ======================== -->

        <div class="cart-wrapper">

            <div class="note-block">
                <div class="row">

                    <!-- === left content === -->

                    <div class="col-md-8">

                        <!-- === login-wrapper === -->

                        <div class="login-wrapper">

                            <div class="white-block">
                                <h4>Billing Address</h4>

                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="First name: *">
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="Last name: *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="Email: *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="Phone: *">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="account-confirm-pass">Address</label>
                                            <textarea class="form-control" type="text" id=""
                                                value="Address"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="City: *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="Zip code: *">
                                        </div>
                                    </div>


                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="state">
                                        </div>
                                    </div>
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="Country">
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <span class="checkbox">
                                            <input type="checkbox" id="checkBoxId3">
                                            <label for="checkBoxId3">click here for same shipping
                                                address.</label>
                                        </span>
                                    </div>


                                </div>


                                <h4>Shipping Address</h4>
                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="First name: *">
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="Last name: *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="Email: *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="Phone: *">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="account-confirm-pass">Address</label>
                                            <textarea class="form-control" type="text" id=""
                                                value="Address"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="City: *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="Zip code: *">
                                        </div>
                                    </div>


                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="state">
                                        </div>
                                    </div>
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <input type="text" value="" class="form-control"
                                                placeholder="Country">
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <h4>Payment Method</h4>
                                        <span class="checkbox">
                                            <input type="checkbox" id="checkBoxId4">
                                            <label for="checkBoxId4">Online Payment</label>
                                        </span>
                                    </div>


                                </div>

                                
                            </div>
                        </div>

                        <!--/login-wrapper-->
                    </div>
                    <div class="col-md-4">
                        <div class="col-md-4 col-sm-12 col-xs-12 pay">
                            <div class="BillingTable">
                                <table class="table">
                                    <thead>
                                        <tr class="borders-b">
                                            <th class="f-20">Cart</th>
                                            <th class="t-right f-20">Rent</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            
                                            <td>All Appliances Combo</td>
                                            <td class="t-right">₹ 3699</td>
                                        </tr>
                                    </tbody>
                                    <thead>
                                        <tr class="borders-t">
                                            <th>Refundable Deposit</th>

                                            <th class="t-right">₹ 6200 /-</th>
                                        </tr>
                                        <tr>
                                            <td>Delivery Charge</td>

                                            <td class="t-right">₹ 0 /-</td>
                                        </tr>
                                        <tr class="borders-t">
                                            <th>Total</th>

                                            <th class="t-right">₹ 9899 /-</th>
                                        </tr>
                                    </thead>
                                </table>
                               
                            </div>

                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

        <!-- ========================  Cart wrapper ======================== -->



        <!-- ========================  Cart navigation ======================== -->

        <div class="clearfix">
            <div class="row">
                <div class="col-xs-6">
                    <a href="profile.php" class="btn btn-main"style="width: 14rem;">
                        <p class="para"><span class="icon icon-chevron-left"></span> Back to cart</p>
                    </a>
                </div>
                <div class="col-xs-6 text-right">
                    <a href="#" class="btn btn-main" style="width: 19rem;">
                        <p class="para"><span class="icon icon-cart"></span> Go to payment</p>
                    </a>
                </div>
            </div>
        </div>


    </div>
    <!--/container-->

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/layouts/checkout.blade.php ENDPATH**/ ?>