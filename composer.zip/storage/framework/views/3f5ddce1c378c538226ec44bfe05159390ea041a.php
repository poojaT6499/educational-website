

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Add livemeetings</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(Request::root()); ?>/admin/dashboard">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(Request::root()); ?>/admin/livemeetings">livemeetings</a>
                </li>
                <li class="breadcrumb-item active"><a href="<?php echo e(Request::root()); ?>/admin/livemeetings/add-livemeetings">Add
                        livemeetings</a>
                </li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12 col-xxl-12 col-sm-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-body">
                        <form role="form" method="post"
                            action="<?php echo e(Request::root()); ?>/admin/livemeetings/add-livemeetings-post"
                            enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="form-group">
                                <label for="classID">Choose Class:</label>
                                <select name="classID" id="classID">
                                    <?php $__currentLoopData = $classData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->ClassID); ?>"><?php echo e($item->ClassTitle); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="courseID">Choose Course:</label>
                                <select name="courseID" id="courseID">
                                    <?php $__currentLoopData = $courseData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($itemm->CourseID); ?>"><?php echo e($itemm->CourseTitle); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="time">Time:</label>
                                <input type="time" class="form-control" id="time" name="time">
                            </div>
                            <div class="form-group">
                                <label for="meetingUrl">livemeetings Url:</label>
                                <input type="text" class="form-control" id="meetingUrl" name="meetingUrl">
                            </div>

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\learningApp\resources\views/admin/livemeeting/add.blade.php ENDPATH**/ ?>