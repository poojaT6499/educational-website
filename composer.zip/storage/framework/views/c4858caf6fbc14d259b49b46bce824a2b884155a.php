<div class="dlabnav">
    <div class="dlabnav-scroll">
        <ul class="metismenu" id="menu">
            <li class="nav-label first">Main Menu</li>
            <li>
                <a class="" href="<?php echo e(route('admin')); ?>" aria-expanded="false">
                    <i class="la la-home"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li>
                <a class="" href="<?php echo e(route('admin.banner')); ?>" aria-expanded="false">
                    <i class="la la-image"></i>
                    <span class="nav-text">Banners</span>
                </a>
            </li>
            <li>
                <a class="" href="<?php echo e(route('admin.classes')); ?>" aria-expanded="false">
                    <i class="la la-graduation-cap"></i>
                    <span class="nav-text">Classes</span>
                </a>
            </li>
            <li>
                <a class="" href="<?php echo e(route('admin.subject')); ?>" aria-expanded="false">
                    <i class="la la-book"></i>
                    <span class="nav-text">Subjects</span>
                </a>
            </li>
            <li>
                <a class="" href="<?php echo e(route('admin.teacher')); ?>" aria-expanded="false">
                    <i class="la la-users"></i>
                    <span class="nav-text">Teachers</span>
                </a>
            </li>
            <li>
                <a class="" href="<?php echo e(route('admin.student')); ?>" aria-expanded="false">
                    <i class="la la-users"></i>
                    <span class="nav-text">Students</span>
                </a>
            </li>
            

        </ul>
    </div>
</div>
<?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/layouts/admin/partials/_sidebar.blade.php ENDPATH**/ ?>