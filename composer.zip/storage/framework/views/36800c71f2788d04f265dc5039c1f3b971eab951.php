<div class="nav-header">
    <a href="javascript:void(0)" class="brand-logo">
        <h3 style="color:#fff; font-weight: 600;">Manoj Academy</h3>
        
        
        
    </a>
    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span><span class="line"></span><span class="line"></span>
        </div>
    </div>
</div>


<div class="header">
    <div class="header-content">
        <nav class="navbar navbar-expand">
            <div class="collapse navbar-collapse justify-content-between">
                <div class="header-left">
                    
                </div>
                <ul class="navbar-nav header-right">
                    
                    <li class="nav-item dropdown header-profile">
                        <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                            <img src="<?php echo e(asset('assets/admin/images/profile/education/pic1.jpg')); ?>" width="20" alt="">
                            <span> <?php if(Auth::guard('webadmin')->user()): ?>

                                <?php echo e(Auth::guard('webadmin')->user()->name); ?>



                                <?php endif; ?>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">

                            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item ai-icon"
                                onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                <svg id="icon-logout" xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                    viewbox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round" class="feather feather-log-out">
                                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                                    <polyline points="16 17 21 12 16 7"></polyline>
                                    <line x1="21" y1="12" x2="9" y2="12"></line>
                                </svg>
                                
                                <span>

                                    


                                    Logout
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                        style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </span>
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/layouts/teacher/partials/_header.blade.php ENDPATH**/ ?>