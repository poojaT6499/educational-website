
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Add Media</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(Request::root()); ?>/admin/dashboard">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(Request::root()); ?>/admin/Media">Media</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(Request::root()); ?>/admin/Media/add-Media">Add
                        Media</a>
                </li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <ul class="nav nav-pills mb-3">
                <li class="nav-item"><a href="#list-view" data-toggle="tab"
                        class="nav-link btn-primary mr-1 show active">List View</a></li>
                <li class="nav-item"><a href="#grid-view" data-toggle="tab" class="nav-link btn-primary">Grid View</a>
                </li>
            </ul>
        </div>
        <div class="col-lg-12">
            <div class="row tab-content">
                <div id="list-view" class="tab-pane fade active show col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">All Media </h4>
                            <a href="<?php echo e(Request::root()); ?>/admin/Media/add-Media" class="btn btn-primary">+ Add
                                new</a>
                        </div>
                        <div class="card-body">
                            <?php if(Session::has('message')): ?>
                            <div class="alert alert-success">
                                <strong><span class="glyphicon glyphicon-ok"></span><?php echo e(Session::get('message')); ?></strong>
                            </div>
                            <?php endif; ?>
                            <div class="table-responsive">
                                <?php if(count($Media)>0): ?>
                                <table id="example3" class="display" style="min-width: 845px">
                                    <thead>
                                        <tr>
                                            <th>SL No</th>
                                            <th>Chapter Name</th>
                                            <th>Media Type</th>
                                            <th>Media Url</th>
                                            <th>Media Title</th>
                                            <th>Media SubTitle</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i=1 ?>
                                        <?php $__currentLoopData = $Media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MediaData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($i); ?> </td>
                                            <td><?php echo e($MediaData->ChapterID); ?></td>
                                            <td><?php echo e(Str::substr($MediaData->MediaType,0,10)); ?></td>
                                            <td><?php echo e(Str::substr($MediaData->MediaUrl,0,20)); ?></td>
                                            <td><?php echo e(Str::substr($MediaData->MediaTitle,0,20)); ?></td>
                                            <td><?php echo e(Str::substr($MediaData->MediaSubTitle,0,20)); ?></td>
                                            <td>
                                                <a href="<?php echo e(Request::root()); ?>/admin/Media/change-status-Media/<?php echo e($MediaData->MediaID); ?>"
                                                    class="btn btn-sm btn-warning"> <?php if($MediaData->Status==1): ?>
                                                    <?php echo e("Activate"); ?> <?php else: ?> <?php echo e("Dectivate"); ?> <?php endif; ?> </a>

                                                <a href="<?php echo e(Request::root()); ?>/admin/Media/edit-Media/<?php echo e($MediaData->MediaID); ?>"
                                                    class="btn btn-sm btn-primary"><i class="la la-pencil"></i></a>
                                                <a href="<?php echo e(Request::root()); ?>/admin/Media/delete-Media/<?php echo e($MediaData->MediaID); ?>"
                                                    onclick="return confirm('are you sure to delete')"
                                                    class="btn btn-sm btn-danger"><i class="la la-trash-o"></i></a>
                                            </td>
                                        </tr>

                                        <?php $i++;  ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <?php else: ?>
                                <div class="alert alert-info" role="alert">
                                    <strong>No Plan Found!</strong>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="grid-view" class="tab-pane fade col-lg-12">
                    <div class="row">
                        <?php $__currentLoopData = $Media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MediaData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="card card-profile">
                                <div class="card-header justify-content-end pb-0">
                                    <div class="dropdown">
                                        <button class="btn btn-link" type="button" data-toggle="dropdown">
                                            <span class="dropdown-dots fs--1"></span>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right border py-0">
                                            <div class="py-2">
                                                <a href="<?php echo e(Request::root()); ?>/admin/Media/view-Media/<?php echo e($MediaData->MediaID); ?>"
                                                    class="ml-4"> <?php if($MediaData->Status==1): ?> <?php echo e("Activate"); ?> <?php else: ?>
                                                    <?php echo e("Dectivate"); ?> <?php endif; ?> </a>

                                                <a href="<?php echo e(Request::root()); ?>/admin/Media/edit-Media/<?php echo e($MediaData->MediaID); ?>"
                                                    class="ml-4">Edit</a>
                                                <a href="<?php echo e(Request::root()); ?>/admin/Media/delete-Media/<?php echo e($MediaData->MediaID); ?>"
                                                    onclick="return confirm('are you sure to delete')" class="ml-4">
                                                    Delete</a>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body pt-2">
                                    <div class="text-center">
                                        <h3 class="mt-4 mb-1"><?php echo e($MediaData->MediaType); ?></h3>


                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\learningApp\resources\views/admin/media/index.blade.php ENDPATH**/ ?>