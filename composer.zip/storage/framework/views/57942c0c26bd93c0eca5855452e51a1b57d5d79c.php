

<?php $__env->startSection('content'); ?>
    

<section class="header-content">


    <div class="owl-slider">

        <!-- === slide item === -->

        <div class="item" style="background-image:url(<?php echo e(asset('/assets/images/banner5.jpg')); ?>)">
            <div class="box">
                <div class="container">
                    <h2 class="title animated h1" data-animation="fadeInDown">Lorem, ipsum dolor.</h2>
                    <div class="animated" data-animation="fadeInUp">
                        Lorem ipsum dolor sit. <br />Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                        Aperiam, quisquam!
                    </div>
                    <div class="animated" data-animation="fadeInUp">
                        <a href="javascript:void(0)" target="_blank" class="btn btn-main">
                            <p style="margin: 1rem;"><i class="icon icon-cart"></i> Rent </p>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- === slide item === -->

        <div class="item" style="background-image:url(<?php echo e(asset('/assets/images/banner5.jpg')); ?>)">
            <div class="box">
                <div class="container">
                    <h2 class="title animated h1" data-animation="fadeInDown">Lorem, ipsum.</h2>
                    <div class="animated" data-animation="fadeInUp">Lorem ipsum, dolor sit amet consectetur
                        adipisicing elit. Natus, optio?</div>
                    <div class="animated" data-animation="fadeInUp">Lorem ipsum dolor sit amet.</div>
                    <div class="animated" data-animation="fadeInUp">
                        <a href="javascript:void(0)" class="btn btn-main">
                            <p style="margin: 1rem;">Get insipred</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- === slide item === -->

        <div class="item" style="background-image:url(<?php echo e(asset('/assets/images/banner5.jpg')); ?>)">
            <div class="box">
                <div class="container">
                    <h2 class="title animated h1" data-animation="fadeInDown">
                        Lorem ipsum dolor sit amet.
                    </h2>
                    <div class="desc animated" data-animation="fadeInUp">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. A, nesciunt?
                    </div>
                    <div class="desc animated" data-animation="fadeInUp">
                        Lorem ipsum dolor sit amet consectetur..
                    </div>
                    <div class="animated" data-animation="fadeInUp">
                        <a href="javascript:void(0)" target="_blank" class="btn btn-main">
                            <p style="margin: 1rem;">Rent</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!--/owl-slider-->
</section>

<!-- ========================  Icons slider ======================== -->

<section class="owl-icons-wrapper owl-icons-frontpage">

    <!-- === header === -->

    <header class="hidden">
        <h2>Product categories</h2>
    </header>


    <div class="container">



        <ul class="nav nav-tabs custom">
            <li class="active"><a data-toggle="tab" href="#product">Products</a></li>
            <li><a data-toggle="tab" href="#build">Customize</a></li>

        </ul>

        <div class="tab-content">
            <div id="product" class="tab-pane fade in active">
                <div class="owl-icons">



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-sofa color2"></i>
                            <figcaption class="color1">Sofa</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-armchair color2"></i>
                            <figcaption class="color1">Armchairs</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-chair color2"></i>
                            <figcaption class="color1">Chairs</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-dining-table color2"></i>
                            <figcaption class="color1">Dining tables</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-media-cabinet color2"></i>
                            <figcaption class="color1">Media storage</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-table color2"></i>
                            <figcaption class="color1">Tables</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-bookcase color2"></i>
                            <figcaption class="color1">Bookcase</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-bedroom color2"></i>
                            <figcaption class="color1">Bedroom</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-nightstand color2"></i>
                            <figcaption class="color1">Nightstand</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-children-room color2"></i>
                            <figcaption class="color1">Children room</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-kitchen color2"></i>
                            <figcaption class="color1">Kitchen</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-bathroom color2"></i>
                            <figcaption class="color1">Bathroom</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-wardrobe color2"></i>
                            <figcaption class="color1">Wardrobe</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-shoe-cabinet color2"></i>
                            <figcaption class="color1">Shoe cabinet</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-office color2"></i>
                            <figcaption class="color1">Office</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-bar-set color2"></i>
                            <figcaption class="color1">Bar sets</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-lightning color2"></i>
                            <figcaption class="color1">Lightning</figcaption>
                        </figure>
                    </a>



                    <a href="products-grid.php">
                        <figure>
                            <i class="f-icon f-icon-carpet color2"></i>
                            <figcaption class="color1">Varpet</figcaption>
                        </figure>
                    </a>



                    <a href="javascript:void(0)">
                        <figure>
                            <i class="f-icon f-icon-accessories color2"></i>
                            <figcaption class="color1">Accessories</figcaption>
                        </figure>
                    </a>
                </div>
            </div>
            <div id="build" class="tab-pane fade">
                <div class="owl-icons">
                    <div class="row custom1 ">
                        <div class="col-md-5 col-xs-9 " style="margin: 2rem;">
                            <p class="mt6">Unleash the designer in you and create a package that suits your needs.<p>
                        </div>
                        <div class="col-md-5 col-xs-4 dis">
                            <div class="dis">
                                <a href="javascript:void(0)">
                                    <figure>
                                        <img src="<?php echo e(asset('/assets/images/bed1.png')); ?>" class="img1">
                                        <figcaption class="color1 mt2">Choose <br>a furniture</figcaption>
                                    </figure>
                                </a>
                                <i class="fa fa-chevron-right arr" aria-hidden="true"></i>
                            </div>
                            <div class="dis">
                                <a href="javascript:void(0)">
                                    <figure>
                                        <img src="<?php echo e(asset('/assets/images/pillows.png')); ?>" class="img2">
                                        <figcaption class="color1 mt2">Add <br>soft-furnishings
                                        </figcaption>
                                    </figure>
                                </a>
                                <i class="fa fa-chevron-right arr" aria-hidden="true"></i>
                            </div>
                            <div class="">
                                <a href="javascript:void(0)">
                                    <figure>
                                        <img src="<?php echo e(asset('/assets/images/appliances.png')); ?>" class="img3">
                                        <figcaption class="color1 mt2">Select<br> Appliances
                                        </figcaption>
                                    </figure>
                                </a>

                            </div>
                            <!-- <div class="wrapper-more">
                                <a href="customize.php" class=" btn btn-main" style="margin-left: 6rem;">
                                    <p style="margin: 1rem; color: white; ">Get Started</p>
                                </a>
                            </div> -->
                        </div>
                        <div class="col-md-2 col-xs-4">
                            <div class="wrapper-more">
                                <a href="customize.php" class=" btn btn-main custombtn" >
                                    <p style="margin: 1rem; color: white; ">Get Started</p>
                                </a>
                            </div>
                        </div>


                    </div>


                </div>
            </div>
        </div>
    </div>
</section>


<!-- ========================  Products widget ======================== -->

<section class="products">

    <div class="container">

        <!-- === header title === -->

        <header>
            <div class="row">
                <div class="col-md-offset-2 col-md-8 text-center">
                    <h2 class="title">Trending Product</h2>
                    <!-- <h3>appliances</h3> -->

                    <!-- <div class="text">
                        <p>Check out our latest collections</p>
                    </div> -->
                </div>
            </div>
        </header>
        <div class="row">

            <!-- === product-item === -->

            <div class="col-md-4 col-xs-6">
                <article>
                    <div class="info">
                        <span class="add-favorite added">
                            <a href="javascript:void(0);" data-title="Add to favorites"
                                data-title-added="Added to favorites list"><i class="icon icon-heart"></i></a>
                        </span>
                        <span>
                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                    class="icon icon-eye"></i></a>
                        </span>
                    </div>
                    <div class="btn btn-add">
                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                    </div>
                    <div id="toast">
                        <div class="checkicon"> <i class="fa fa-check-circle-o" aria-hidden="true"
                                style="color:green;"></i> </div>
                        Item added successfully in cart!
                    </div>
                    <div class="figure-grid">
                        <div class="image">
                            <a href="product.php" class="">
                                <img src="<?php echo e(asset('/assets/images/chair.jpg')); ?>" alt="" width="360" />
                            </a>
                        </div>
                        <div class="text">
                            <h2 class="title h4"><a href="product.php">Green corner</a></h2>
                            <sub>₹ 1499,-</sub>
                            <sup>₹ 1099,-</sup>
                            <span class="description clearfix">Gubergren amet dolor ea diam takimata consetetur
                                facilisis blandit et aliquyam lorem ea duo labore diam sit et consetetur
                                nulla</span>
                        </div>
                    </div>
                </article>
            </div>

            <!-- === product-item === -->

            <div class="col-md-4 col-xs-6">
                <article>
                    <div class="info">
                        <span class="add-favorite">
                            <a href="javascript:void(0);" data-title="Add to favorites"
                                data-title-added="Added to favorites list"><i class="icon icon-heart"></i></a>
                        </span>
                        <span>
                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                    class="icon icon-eye"></i></a>
                        </span>
                    </div>
                    <div class="btn btn-add">
                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                    </div>
                    <div id="toast">
                        <div class="checkicon"> <i class="fa fa-check-circle-o" aria-hidden="true"
                                style="color:green;"></i> </div>
                        Item added successfully in cart!
                    </div>
                    <div class="figure-grid">
                        <div class="image">
                            <a href="product.php" class="">
                                <img src="<?php echo e(asset('/assets/images/chair.jpg')); ?>" alt="" width="360" />
                            </a>
                        </div>
                        <div class="text">
                            <h2 class="title h4"><a href="product.php">Laura</a></h2>
                            <sub>₹ 3999,-</sub>
                            <sup>₹ 3499,-</sup>
                            <span class="description clearfix">Gubergren amet dolor ea diam takimata consetetur
                                facilisis blandit et aliquyam lorem ea duo labore diam sit et consetetur
                                nulla</span>
                        </div>
                    </div>
                </article>
            </div>

            <!-- === product-item === -->

            <div class="col-md-4 col-xs-6">
                <article>
                    <div class="info">
                        <!-- <span class="label label-warning">New</span> -->
                        <span class="add-favorite">
                            <a href="javascript:void(0);" data-title="Add to favorites"
                                data-title-added="Added to favorites list"><i class="icon icon-heart"></i></a>
                        </span>
                        <span>
                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                    class="icon icon-eye"></i></a>
                        </span>
                    </div>
                    <div class="btn btn-add">
                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                    </div>
                    <div id="toast">
                        <div class="checkicon"> <i class="fa fa-check-circle-o" aria-hidden="true"
                                style="color:green;"></i> </div>
                        Item added successfully in cart!
                    </div>
                    <div class="figure-grid">
                        <span class="label label-warning">New</span>
                        <div class="image">
                            <a href="product.php" class="">
                                <img src="<?php echo e(asset('/assets/images/chair.jpg')); ?>" alt="" width="360" />
                            </a>
                        </div>
                        <div class="text">
                            <h2 class="title h4"><a href="product.php">Nude</a></h2>
                            <sup>₹ 2999,-</sup>
                            <span class="description clearfix">Gubergren amet dolor ea diam takimata consetetur
                                facilisis blandit et aliquyam lorem ea duo labore diam sit et consetetur
                                nulla</span>
                        </div>
                    </div>
                </article>
            </div>

            <!-- === product-item === -->

            <div class="col-md-4 col-xs-6">
                <article>
                    <div class="info">
                        <span class="add-favorite">
                            <a href="javascript:void(0);" data-title="Add to favorites"
                                data-title-added="Added to favorites list"><i class="icon icon-heart"></i></a>
                        </span>
                        <span>
                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                    class="icon icon-eye"></i></a>
                        </span>
                    </div>
                    <div class="btn btn-add">
                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                    </div>
                    <div id="toast">
                        <div class="checkicon"> <i class="fa fa-check-circle-o" aria-hidden="true"
                                style="color:green;"></i> </div>
                        Item added successfully in cart!
                    </div>
                    <div class="figure-grid">
                        <div class="image">
                            <a href="product.php" class="">
                                <img src="<?php echo e(asset('/assets/images/chair.jpg')); ?>" alt="" width="360" />
                            </a>
                        </div>
                        <div class="text">
                            <h2 class="title h4"><a href="product.php">Aurora</a></h2>
                            <sup>₹ 299,-</sup>
                            <span class="description clearfix">Gubergren amet dolor ea diam takimata consetetur
                                facilisis blandit et aliquyam lorem ea duo labore diam sit et consetetur
                                nulla</span>
                        </div>
                    </div>
                </article>
            </div>

            <!-- === product-item === -->

            <div class="col-md-4 col-xs-6">
                <article>
                    <div class="info">
                        <span class="add-favorite added">
                            <a href="javascript:void(0);" data-title="Add to favorites"
                                data-title-added="Added to favorites list"><i class="icon icon-heart"></i></a>
                        </span>
                        <span>
                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                    class="icon icon-eye"></i></a>
                        </span>
                    </div>
                    <div class="btn btn-add">
                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                    </div>
                    <div id="toast">
                        <div class="checkicon"> <i class="fa fa-check-circle-o" aria-hidden="true"
                                style="color:green;"></i> </div>
                        Item added successfully in cart!
                    </div>
                    <div class="figure-grid">
                        <span class="label label-info">-50%</span>
                        <div class="image">
                            <a href="product.php" class="">
                                <img src="<?php echo e(asset('/assets/images/chair.jpg')); ?>" alt="" width="360" />
                            </a>
                        </div>
                        <div class="text">
                            <h2 class="title h4"><a href="product.php">Dining set</a></h2>
                            <sub>₹ 1999,-</sub>
                            <sup>₹ 1499,-</sup>
                            <span class="description clearfix">Gubergren amet dolor ea diam takimata consetetur
                                facilisis blandit et aliquyam lorem ea duo labore diam sit et consetetur
                                nulla</span>
                        </div>
                    </div>
                </article>
            </div>

            <!-- === product-item === -->

            <div class="col-md-4 col-xs-6">
                <article>
                    <div class="info">
                        <span class="add-favorite">
                            <a href="javascript:void(0);" data-title="Add to favorites"
                                data-title-added="Added to favorites list"><i class="icon icon-heart"></i></a>
                        </span>
                        <span>
                            <a href="#productid1" class="mfp-open" data-title="Quick wiew"><i
                                    class="icon icon-eye"></i></a>
                        </span>
                    </div>
                    <div class="btn btn-add">
                        <i class="icon icon-cart" onclick="toastFunction()"></i>
                    </div>
                    <div id="toast">
                        <div class="checkicon"> <i class="fa fa-check-circle-o" aria-hidden="true"
                                style="color:green;"></i> </div>
                        Item added successfully in cart!
                    </div>
                    <div class="figure-grid">
                        <div class="image">
                            <a href="#productid1" class="mfp-open">
                                <img src="<?php echo e(asset('/assets/images/chair.jpg')); ?>" alt="" width="360" />
                            </a>
                        </div>
                        <div class="text">
                            <h2 class="title h4"><a href="product.php">Seat chair</a></h2>
                            <sup>₹ 896,-</sup>
                            <span class="description clearfix">Gubergren amet dolor ea diam takimata consetetur
                                facilisis blandit et aliquyam lorem ea duo labore diam sit et consetetur
                                nulla</span>
                        </div>
                    </div>
                </article>
            </div>

        </div>
        <!--/row-->
        <!-- === button more === -->

        <div class="wrapper-more">
            <a href="products-grid.php" class=" btn btn-main">
                <p style="margin: 1rem;">View store</p>
            </a>
        </div>

        <!-- ========================  Product info popup - quick view ======================== -->

        <div class="popup-main mfp-hide" id="productid1">

            <!-- === product popup === -->

            <div class="product">

                <!-- === popup-title === -->

                <div class="popup-title">
                    <div class="h1 title">Laura <small>product category</small></div>
                </div>

                <!-- === product gallery === -->

                <div class="owl-product-gallery">
                    <img class="imgw" src="<?php echo e(asset('/assets/images/sofa.jpg')); ?>" alt="" height="640" />
                    <img class="imgw" src="<?php echo e(asset('/assets/images/sofa.jpg')); ?>" alt="" height="640" />
                    <img class="imgw" src="<?php echo e(asset('/assets/images/sofa.jpg')); ?>" alt="" height="640" />
                    <img class="imgw" src="<?php echo e(asset('/assets/images/sofa.jpg')); ?>" alt="" height="640" />
                </div>

                <!-- === product-popup-info === -->

                <div class="popup-content">
                    <div class="product-info-wrapper">
                        <div class="container">
                            <div class="tile-package-variants">
                            </div>
                            <div class="basic" style="margin-left: 15rem;">
                                <button class="tablinks btn btn-main" onclick="openCity(event, 'product')"
                                    id="basicBtn">Basic</button>
                                <button class="tablinks btn btn-main"
                                    onclick="openCity(event, 'product1')">Primium</button>

                            </div>
                            <div id="product" class="tabcontent">
                                <div class="tile-items d-flex flex-column">
                                    <div class="tile-items-heading">2 ITEMS</div>
                                    <div class="d-flex">
                                        <div
                                            class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                            <div
                                                class="item-oval d-flex justify-content-center align-items-center">
                                                <img src="<?php echo e(asset('/assets/images/Queen_Bed.jpg')); ?>"
                                                    itemprop="image" width="100%">
                                            </div>
                                            <div class="">
                                                <!-- <span>1 unit</span> -->
                                            </div>
                                        </div>
                                        <div
                                            class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                            <div
                                                class="item-oval d-flex justify-content-center align-items-center">
                                                <img src="<?php echo e(asset('/assets/images/Queen_Bed.jpg')); ?>"
                                                    itemprop="image" width="100%"></div>
                                            <div class="">
                                                <!-- <span>1 unit</span> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div id="product1" class="tabcontent">
                                <div class=" tile-items d-flex flex-column">
                                    <div class="tile-items-heading">3 ITEMS</div>
                                    <div class="d-flex">
                                        <div
                                            class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                            <div
                                                class="item-oval d-flex justify-content-center align-items-center">
                                                <img src="<?php echo e(asset('/assets/images/Queen_Bed.jpg')); ?>"
                                                    itemprop="image" width="100%"></div>
                                            <div class="">
                                                <!-- <span>1 unit</span> -->
                                            </div>
                                        </div>
                                        <div
                                            class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                            <div
                                                class="item-oval d-flex justify-content-center align-items-center">
                                                <img src="<?php echo e(asset('/assets/images/Queen_Bed.jpg')); ?>"
                                                    itemprop="image" width="100%"></div>
                                            <div class="">
                                                <!-- <span>1 unit</span> -->
                                            </div>
                                        </div>
                                        <div
                                            class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                            <div
                                                class="item-oval d-flex justify-content-center align-items-center">
                                                <img src="<?php echo e(asset('/assets/images/Queen_Bed.jpg')); ?>"
                                                    itemprop="image" width="100%"></div>
                                            <div class="">
                                                <!-- <span>1 unit</span></div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <!--/row-->
                    </div>
                    <!--/product-info-wrapper-->
                </div>
                <!--/popup-content-->
                <!-- === product-popup-footer === -->

                <div class="popup-table">
                    <div class="popup-cell">
                        <div class="price">
                            <span class="h3">₹ 1999,00 <small>₹ 2999,00</small></span>
                        </div>
                    </div>
                    <div class="popup-cell">
                        <div class="popup-buttons">
                            <a href="product.php"><span class="icon icon-eye"></span> <span
                                    class="hidden-xs">View more</span></a>
                            <a href="javascript:void(0);"><span class="icon icon-cart"></span> <span
                                    class="hidden-xs">Rent</span></a>
                        </div>
                    </div>
                </div>

            </div>
            <!--/product-->
        </div>
        <!--popup-main-->
    </div>
    <!--/container-->
</section>


<section class="benefits-section flex-full">
    <div class="container">
        <h2 class="w-100 text-center border-center">Why You should rent with<br> RentoFurnish.</h2>
        <ul class="benefits-listing flex-full">
            <li>
                <img src="<?php echo e(asset('/assets/images/delivery-truck.png')); ?>" hight="60px" width="60px">


                <span>Free Delivery</span>

                <p>We ensure that products delivered at your place without any hassle! Free shipping best
                    quality furniture.</p>
            </li>
            <li>
                <img src="<?php echo e(asset('/assets/images/up.png')); ?>" hight="50px" width="50px">

                <span>Free Upgrade</span>

                <p>Bored with same furniture? Try new look/design upgrade furniture.</p>
            </li>
            <li>
                <img src="<?php echo e(asset('/assets/images/destination.png')); ?>" hight="50px" width="50px">

                <span>Free Relocation</span>

                <p>As of now its under review ! We are working hard for you.</p>
            </li>

        </ul>

    </div>
    <div class="container">
        <ul class="benefits-listing flex-full">
            <li>
                <img src="<?php echo e(asset('/assets/images/tools.png')); ?>" hight="50px" width="50px">

                <span>Free Installation</span>

                <p>The installation will be free of cost! At the time of delivery we will help you with free
                    demo &amp; installation.</p>
            </li>
            <li>
                <img src="<?php echo e(asset('/assets/images/condition.png')); ?>" hight="50px" width="50px">

                <span>Mint Condition</span>

                <p>All products are well maintained &amp; as good as new condition ! Quality matters for us so
                    we check products before delivery.</p>
            </li>
            <li>
                <img src="http://rentofurnish.com/frontendtheme/images/logo/maintenance.png" hight="50px"
                    width="50px">

                <span>Free Maintenance</span>

                <p>Worried about Maintenance? Just sit back &amp; Relaxe&nbsp; we will help u with all free
                    Service.</p>
            </li>
        </ul>
    </div>
</section>
<section id="testim" class="testim">
    <div class="container">
        <h2 class="w-100 text-center border-center">Client Testimonial</h2>
        <div class="testim-cover">
            <div class="wrap">

                <span id="right-arrow" class="arrow right fa fa-chevron-right"></span>
                <span id="left-arrow" class="arrow left fa fa-chevron-left "></span>
                <ul id="testim-dots" class="dots">
                    <li class="dot active"></li>

                    <li class="dot"></li>

                    <li class="dot"></li>

                    <li class="dot"></li>


                    <li class="dot"></li>
                </ul>
                <div id="testim-content" class="cont">

                    <div class="active">
                        <div class="img"><img src="<?php echo e(asset('/assets/images/testi.jpg')); ?>" alt=""></div>
                        <h2>Akash mahadev pote</h2>
                        <p>Rentofurnish is the way better option for furniture. Nice quality of products and the
                            staff is very humble and supportive, Simply love Rentofurnish for its quality and
                            products.
                        </p>
                    </div>

                    <div>
                        <div class="img"><img src="<?php echo e(asset('/assets/images/testi.jpg')); ?>" alt=""></div>
                        <h2>Akash mahadev pote</h2>
                        <p>Rentofurnish is the way better option for furniture. Nice quality of products and the
                            staff is very humble and supportive, Simply love Rentofurnish for its quality and
                            products.
                        </p>
                    </div>

                    <div>
                        <div class="img"><img src="<?php echo e(asset('/assets/images/testi.jpg')); ?>" alt=""></div>
                        <h2>Akash mahadev pote</h2>
                        <p>Rentofurnish is the way better option for furniture. Nice quality of products and the
                            staff is very humble and supportive, Simply love Rentofurnish for its quality and
                            products.
                        </p>
                    </div>

                    <div>
                        <div class="img"><img src="<?php echo e(asset('/assets/images/testi.jpg')); ?>" alt=""></div>
                        <h2>Aditi Chaturvedi</h2>
                        <p>
                            A regular customer. Already have a double bed and side table. Very good collection
                            and very nice and helping staff. And really good customer support team. All the best
                            for great future.
                        </p>
                    </div>

                    <div>
                        <div class="img"><img src="<?php echo e(asset('/assets/images/testi.jpg')); ?>" alt=""></div>
                        <h2>Ms. Lorem R. Ipsum</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                            exercitation ullamco.</p>
                    </div>

                </div>

            </div>
        </div>
    </div>
</section>


<script src="https://use.fontawesome.com/1744f3f671.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/layouts/index.blade.php ENDPATH**/ ?>