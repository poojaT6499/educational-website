

<?php $__env->startSection('content'); ?>


<section></section>
<section class="checkout">

    <div class="container">

        <h1> My Cart</h1>
        <header class="hidden">
            <h3 class="h3 title">Checkout - Step 1</h3>
        </header>

        <!-- ========================  Cart wrapper ======================== -->

        <div class="row">
            <div class="col-md-8 col-12">
                <div class="">
                    <!--cart header -->

                    <div class="cart-block cart-block-header clearfix">
                        <div>
                            <span>Product</span>
                        </div>
                        <div>
                            <span>&nbsp;</span>
                        </div>
                        <div>
                            <span>Quantity</span>
                        </div>
                        <div class="text-right">
                            <span>Price</span>
                        </div>
                    </div>

                    <!--cart items-->

                    <div class="clearfix">
                        <div class="cart-block cart-block-item clearfix">
                            <div class="image">
                                <a href="product.php"><img src="assets/images/chair3.jpg" alt="" /></a>
                            </div>
                            <div class="title">
                                <div class="h4"><a href="product.php">Green corner</a></div>

                            </div>
                            <div class="quantity">
                                <div class="value-button minus" id="decrease" onclick="decreaseValue()"
                                    value="Decrease Value">-</div>
                                <input class="num" type="number" id="number" value="0" />
                                <div class="value-button plus" id="increase" onclick="increaseValue()"
                                    value="Increase Value">+</div>
                            </div>
                            <div class="price">
                                <span class="final h3">Rs 1.998</span>
                                <span class="discount">Rs 2.666</span>
                            </div>
                            <!--delete-this-item-->
                            <span class="icon icon-cross icon-delete"></span>
                        </div>

                        <div class="cart-block cart-block-item clearfix">
                            <div class="image">
                                <a href="product.php"><img src="assets/images/chair3.jpg" alt="" /></a>
                            </div>
                            <div class="title">
                                <div class="h4"><a href="product.php">Green corner</a></div>

                            </div>
                            <div class="quantity">
                            <div class="value-button minus" id="decrease" onclick="decreaseValue()"
                                    value="Decrease Value">-</div>
                                <input class="num" type="number" id="number" value="0" />
                                <div class="value-button plus" id="increase" onclick="increaseValue()"
                                    value="Increase Value">+</div>
                            </div>
                            <div class="price">
                                <span class="final h3">Rs 1.998</span>
                                <span class="discount">Rs 2.666</span>
                            </div>
                            <!--delete-this-item-->
                            <span class="icon icon-cross icon-delete"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <article>
                    <div class="card">
                        <div class="card-body" style="padding: 2rem; background-color: white;">
                            <div class="row">
                                <div class="col-md-7 col-xs-6">
                                    <h4>basic </h4>
                                    <span>6 Products</span>
                                </div>
                                <div class="col-md-5  col-xs-6">
                                    <a href="plans.php" class="btn btn-main">
                                        <p style="margin: 1rem;">Change</p>
                                    </a>
                                </div>
                            </div>
                            <hr>
                            <div class="clearfix">
                                <div class="cart-block cart-block-item clearfix">
                                    <div class="row">
                                        <div class="col-md-7 col-xs-6">
                                            <div class="">
                                                <div class="h6"><a href="product.php">basic Cost</a><br>
                                                    <span>₹1000 x 12</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-xs-6">
                                            <div class="price">
                                                <span class="final h6">₹ 1.998</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="cart-block cart-block-item clearfix">
                                    <div class="row">
                                        <div class="col-md-7 col-xs-6">
                                            <div class="">
                                                <div class="h6"><a href="product.php">Delivery & Installantion
                                                    </a><br>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-xs-6">
                                            <div class="price">
                                                <span class="final h6">₹ 1.998</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="cart-block cart-block-item clearfix">
                                    <div class="row">
                                        <div class="col-md-7 col-xs-6">
                                            <div class="">
                                                <div class="h6"><a href="product.php">Refundable Deposit</a><br>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-xs-6">
                                            <div class="price">
                                                <span class="final h6">₹ 1.998</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="cart-block cart-block-item clearfix">
                                    <div class="row">
                                        <div class="col-md-7 col-xs-6">
                                            <div class="">
                                                <div class="h6"><a href="product.php">GST</a><br>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-xs-6">
                                            <div class="price">
                                                <span class="final h6">₹ 1.998</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="cart-block cart-block-item clearfix">
                                    <div class="row">
                                        <div class="col-md-7 col-xs-6">
                                            <div class="">
                                                <div class="h6"><a href="product.php">Total</a><br>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-xs-6">
                                            <div class="price">
                                                <span class="final h6">₹ 1.998</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="wrapper-more">
                                <a href="#" class="btn btn-main">
                                    <p style="margin: 1rem;">Continue</p>
                                </a>
                                <h6>Free delivery and setup in 7-10 days.</h6>
                            </div>
                        </div>
                    </div>
                </article>
            </div>



        </div>

        <!-- ========================  Cart navigation ======================== -->



    </div>
    <!--/container-->

</section>


<script>
    function increaseValue() {
      var value = parseInt(document.getElementById('number').value, 10);
      value = isNaN(value) ? 0 : value;
      value++;
      document.getElementById('number').value = value;
    }
    
    function decreaseValue() {
      var value = parseInt(document.getElementById('number').value, 10);
      value = isNaN(value) ? 0 : value;
      value < 1 ? value = 1 : '';
      value--;
      document.getElementById('number').value = value;
    }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/layouts/cart.blade.php ENDPATH**/ ?>