<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Add Session</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('teacher')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="">Sessions</a></li>
                <li class="breadcrumb-item active"><a href="">Add Session</a></li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12 col-xxl-12 col-sm-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-body">

                        <form method="POST" action="<?php echo e(route('teacher.session.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="name" class="d-block">Select Class</label>
                                    <select id="classes" class="form-control" name="class_id" onchange="updateSubjects(this.value)">
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($class->id); ?>"><?php echo e($class->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name" class="d-block">Select Subject</label>
                                    <select id="subjects" class="form-control" name="subject_id" onchange="updateChapters(this.value)">
                                        
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name" class="d-block">Select Chapter</label>
                                    <select id="chapters" class="form-control" name="chapter_id">
                                    </select>
                                </div>
                            </div>
                            <hr>
                            <div class="mb-3">
                                <h4>Session Details</h4>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="title">Title:</label>
                                    <input type="text" class="form-control" id="title" name="title" required>
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="link">Link:</label>
                                    <input type="text" class="form-control" id="link" name="link" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="schedule_date">Schedule Date:</label>
                                    <input type="datetime-local" class="form-control" id="schedule_date" name="schedule_date" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name" class="d-block">Select Type</label>
                                    <select id="type" class="form-control" name="type">
                                        <option value="0">Live Session</option>
                                        <option value="1">Doubts Session</option>
                                    </select>
                                </div>
                            </div>
                            <br>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>

window.onload = function() {
    console.log(document.getElementById("classes").value);
    console.log("Subject Id: " + document.getElementById("subjects").value);
    updateSubjects(document.getElementById("classes").value);
    updateChapters(document.getElementById("subjects").value);
};

function removeOptions(selectElement) {
    var i, L = selectElement.options.length - 1;
    for(i = L; i >= 0; i--) {
        selectElement.remove(i);
    }
}

// using the function:
function updateSubjects(class_id) {
    var subjectsSelect = document.getElementById('subjects');
    removeOptions(subjectsSelect);
    $.ajax({
        type: 'GET',
        async: false,
        url: `<?php echo e(url('/teacher/sessions/${class_id}/getSubjects')); ?>`,
        data:'_token = <?php echo csrf_token() ?>',
        success: function(response) {
            var subjects = response.subjects;
            subjects.forEach(subject => {
                var subjectsSelect = document.getElementById('subjects');
                subjectsSelect.options[subjectsSelect.options.length] = new Option(subject.name, subject.id);
            });
            $(subjectsSelect).selectpicker('refresh');
        }
    });
};

// using the function:
function updateChapters(sub_id) {
    var chaptersSelect = document.getElementById('chapters');
    removeOptions(chaptersSelect);
    $.ajax({
        type: 'GET',
        async: false,
        url: `<?php echo e(url('/teacher/questions/${sub_id}/getChapters')); ?>`,
        data:'_token = <?php echo csrf_token() ?>',
        success: function(response) {
            var chapters = response.chapters;
            chapters.forEach(chapter => {
                var chaptersSelect = document.getElementById('chapters');
                chaptersSelect.options[chaptersSelect.options.length] = new Option(chapter.name, chapter.id);
            });
            $(chaptersSelect).selectpicker('refresh');
        }
    });
};

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/teacher/session/create.blade.php ENDPATH**/ ?>