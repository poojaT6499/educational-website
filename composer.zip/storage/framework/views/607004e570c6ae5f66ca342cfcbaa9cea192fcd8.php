<nav class="navbar-fixed">

    <div class="container">

        <!-- ==========  Top navigation ========== -->

        <!-- <div class="navigation navigation-top clearfix">
            <ul>
                <div class="alert alert-light" role="alert">
                    <a href="javascript:void(0)" class="alert-link" style="color:black;">GET FLAT RS.400 OFF ON YOUR RENT. HURRY! OFFER
                        ENDS SOON . T&C APPLY.</a>*
                    <button
                        class="btn rounded-pill font-size-10 offer-explore font-weight-medium letter-spacing-100">Explore</button>
                </div>

            </ul>
        </div> -->
        <!--/navigation-top-->

        <!-- ==========  Main navigation ========== -->

        <div class="navigation navigation-main">

            <!-- Setup your logo here-->

            <a href="index.php" class="logo">
                <img src="<?php echo e(asset('/assets/images/logo1.png')); ?>" alt="" />
            </a>

            <!-- Mobile toggle menu -->

            <a href="javascript:void(0)" class="open-menu"><i class="icon icon-menu"></i></a>

            <!-- Convertible menu (mobile/desktop)-->

            <div class="floating-menu">

                <!-- Mobile toggle menu trigger-->

                <div class="close-menu-wrapper">
                    <span class="close-menu"><i class="icon icon-cross"></i></span>
                </div>

                <ul>
                    <li><a href="javascript:void(0);" class="open-search"><i class="icon icon-magnifier"></i></a>
                </li>
                <li><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size:25px"></i> home</a></li>
                    <li><a href="plans.php ">Plans</a></li>
                    <li><a href="javascript:void(0);" class="open-login"><i class="icon icon-user"></i></a></li>

                    <li><a href="javascript:void(0);" class="open-cart"><i class="icon icon-cart"></i>
                            <span>3</span></a></li>
                    
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-map-marker" aria-hidden="true" style="font-size:25px">
                            </i> mumbai <span class="open-dropdown"><i class="fa fa-angle-down"></i></span></a>
                        <div class="navbar-dropdown navbar-dropdown-single">
                            <div class="navbar-box">

                                <!-- box-2 (without 'box-1', box-2 will be displayed as full width)-->

                                <div class="box-2">
                                    <div class="col-12 box clearfix loc">
                                        <div class="col-md-10 col-xs-9 place form-group">
                                            <div class="select_container">
                                                <select class="form-control" id="country-state" name="country-state">
                                                    <option value="">-Select-</option>
                                                    <option value="AN">Andaman and Nicobar Islands</option>
                                                    <option value="AP">Andhra Pradesh</option>
                                                    <option value="AR">Arunachal Pradesh</option>
                                                    <option value="AS">Assam</option>
                                                    <option value="BR">Bihar</option>
                                                    <option value="CH">Chandigarh</option>
                                                    <option value="CT">Chhattisgarh</option>
                                                    <option value="DN">Dadra and Nagar Haveli</option>
                                                    <option value="DD">Daman and Diu</option>
                                                    <option value="DL">Delhi</option>
                                                    <option value="GA">Goa</option>
                                                    <option value="GJ">Gujarat</option>
                                                    <option value="HR">Haryana</option>
                                                    <option value="HP">Himachal Pradesh</option>
                                                    <option value="JK">Jammu and Kashmir</option>
                                                    <option value="JH">Jharkhand</option>
                                                    <option value="KA">Karnataka</option>
                                                    <option value="KL">Kerala</option>
                                                    <option value="LA">Ladakh</option>
                                                    <option value="LD">Lakshadweep</option>
                                                    <option value="MP">Madhya Pradesh</option>
                                                    <option value="MH">Maharashtra</option>
                                                    <option value="MN">Manipur</option>
                                                    <option value="ML">Meghalaya</option>
                                                    <option value="MZ">Mizoram</option>
                                                    <option value="NL">Nagaland</option>
                                                    <option value="OR">Odisha</option>
                                                    <option value="PY">Puducherry</option>
                                                    <option value="PB">Punjab</option>
                                                    <option value="RJ">Rajasthan</option>
                                                    <option value="SK">Sikkim</option>
                                                    <option value="TN">Tamil Nadu</option>
                                                    <option value="TG">Telangana</option>
                                                    <option value="TR">Tripura</option>
                                                    <option value="UP">Uttar Pradesh</option>
                                                    <option value="UT">Uttarakhand</option>
                                                    <option value="WB">West Bengal</option>
                                                </select>
                                            </div>

                                            <!-- <input class="form-control" placeholder="Search..."
                                                style="border-radius: 20px;" /> -->
                                        </div>
                                        <div class="col-md-2 col-xs-2">
                                            <button class="btn btn-main btn-search"
                                                style="width: 8rem; height: 4.5rem;">Go!</button>
                                        </div>
                                    </div>
                                    <!--/box-->
                                </div>
                                <!--/box-2-->
                            </div>
                            <!--/navbar-box-->
                        </div>
                        <!--/navbar-dropdown-->
                    </li>


                </ul>
            </div>
            <!--/floating-menu-->
        </div>
        <!--/navigation-main-->

        <!-- ==========  Search wrapper ========== -->

        <div class="search-wrapper">

            <!-- Search form -->
            <input class="form-control" placeholder="Search..." />
            <button class="btn btn-main btn-search">Go!</button>

            <!-- Search results - live search -->
            <div class="search-results">
                <div class="search-result-items">
                    <div class="title h4">Products <a href="javascript:void(0)" class="btn btn-clean-dark btn-xs">View all</a>
                    </div>
                    <ul>
                        <li><a href="javascript:void(0)"><span class="id">42563</span> <span class="name">Green corner</span>
                                <span class="category">Sofa</span></a></li>
                        <li><a href="javascript:void(0)"><span class="id">42563</span> <span class="name">Laura</span> <span
                                    class="category">Armchairs</span></a></li>
                        <li><a href="javascript:void(0)"><span class="id">42563</span> <span class="name">Nude</span> <span
                                    class="category">Dining tables</span></a></li>
                        <li><a href="javascript:void(0)"><span class="id">42563</span> <span class="name">Aurora</span> <span
                                    class="category">Nightstands</span></a></li>
                        <li><a href="javascript:void(0)"><span class="id">42563</span> <span class="name">Dining set</span> <span
                                    class="category">Kitchen</span></a></li>
                        <li><a href="javascript:void(0)"><span class="id">42563</span> <span class="name">Seat chair</span> <span
                                    class="category">Bar sets</span></a></li>
                    </ul>
                </div>
                <!--/search-result-items-->
                <div class="search-result-items">
                    <div class="title h4">Blog <a href="javascript:void(0)" class="btn btn-clean-dark btn-xs">View all</a></div>
                    <ul>
                        <li><a href="javascript:void(0)"><span class="id">01 Jan</span> <span class="name">Creating the Perfect
                                    Gallery Wall </span> <span class="category">Interior ideas</span></a></li>
                        <li><a href="javascript:void(0)"><span class="id">12 Jan</span> <span class="name">Making the Most Out of
                                    Your Kids Old Bedroom</span> <span class="category">Interior
                                    ideas</span></a></li>
                        <li><a href="javascript:void(0)"><span class="id">28 Dec</span> <span class="name">Have a look at our new
                                    projects!</span> <span class="category">Modern design</span></a></li>
                        <li><a href="javascript:void(0)"><span class="id">31 Sep</span> <span class="name">Decorating When You're
                                    Starting Out or Starting Over</span> <span class="category">Best of
                                    2017</span></a></li>
                        <li><a href="javascript:void(0)"><span class="id">22 Sep</span> <span class="name">The 3 Tricks that
                                    Quickly Became Rules</span> <span class="category">Tips for you</span></a>
                        </li>
                    </ul>
                </div>
                <!--/search-result-items-->
            </div>
            <!--/search-results-->
        </div>

        <!-- ==========  Login wrapper ========== -->

        <div class="login-wrapper">
            <form>
                <div class="h4">Sign in</div>
                <div class="form-group">
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>
                <div class="form-group">
                    <a href="#forgotpassword" class="open-popup">Forgot password?</a>
                    <a href="#createaccount" class="open-popup">Don't have an account?</a>
                </div>
                <button type="submit" class="btn btn-block btn-main">
                    <a href="profile.php" style="color:white;">Submit</p></a></button>
            </form>
        </div>

        <!-- ==========  Cart wrapper ========== -->

        <div class="cart-wrapper">
            <div class="checkout">
                <div class="clearfix">

                    <!--cart item-->

                    <div class="row">

                        <div class="cart-block cart-block-item clearfix">
                            <div class="image">
                                <a href="product.php"><img src="<?php echo e(asset('/assets/images/couch2.jpg')); ?>" alt="" /></a>
                            </div>
                            <div class="title">
                                <div><a href="product.php">Green corner</a></div>
                                <small>Green corner</small>
                            </div>
                            <div class="quantity">
                                <div class="value-button minus" id="decrease" onclick="decreaseValue()"
                                    value="Decrease Value">-</div>
                                <input class="num" type="number" id="number" value="0" />
                                <div class="value-button plus" id="increase" onclick="increaseValue()"
                                    value="Increase Value">+</div>
                            </div>
                            <div class="price">
                                <span class="final">Rs 1.998</span>
                                <span class="discount">Rs 2.666</span>
                            </div>
                            <!--delete-this-item-->
                            <span class="icon icon-cross icon-delete"></span>
                        </div>

                        <!--cart item-->

                        <div class="cart-block cart-block-item clearfix">
                            <div class="image">
                                <a href="product.php"><img src="<?php echo e(asset('/assets/images/couch2.jpg')); ?>" alt="" /></a>
                            </div>
                            <div class="title">
                                <div><a href="product.php">Green corner</a></div>
                                <small>Green corner</small>
                            </div>
                            <div class="quantity">
                                <div class="value-button minus" id="decrease" onclick="decreaseValue10()"
                                    value="Decrease Value">-</div>
                                <input class="num" type="number" id="number10" value="0" />
                                <div class="value-button plus" id="increase" onclick="increaseValue10()"
                                    value="Increase Value">+</div>
                            </div>
                            <div class="price">
                                <span class="final">Rs 1.998</span>
                                <span class="discount">Rs 2.666</span>
                            </div>
                            <!--delete-this-item-->
                            <span class="icon icon-cross icon-delete"></span>
                        </div>


                    </div>

                    <hr />



                    <!--cart prices -->

                    <div class="clearfix">
                        <div class="cart-block cart-block-footer clearfix">
                            <div>
                                <strong>Discount 15%</strong>
                            </div>
                            <div>
                                <span>Rs 159,00</span>
                            </div>
                        </div>

                        <div class="cart-block cart-block-footer clearfix">
                            <div>
                                <strong>Shipping</strong>
                            </div>
                            <div>
                                <span>Rs 30,00</span>
                            </div>
                        </div>

                        <div class="cart-block cart-block-footer clearfix">
                            <div>
                                <strong>VAT</strong>
                            </div>
                            <div>
                                <span>Rs 59,00</span>
                            </div>
                        </div>
                    </div>

                    <hr />

                    <!--cart final price -->

                    <div class="clearfix">
                        <div class="cart-block cart-block-footer clearfix">
                            <div>
                                <strong>Total</strong>
                            </div>
                            <div>
                                <div class="h4 title">Rs 1259,00</div>
                            </div>
                        </div>
                    </div>


                    <!--cart navigation -->

                    <div class="cart-block-buttons clearfix">
                        <div class="row">
                            <div class="col-xs-6">
                                <a href="products-grid.php" class="btn btn-clean-dark">Continue shopping</a>
                            </div>
                            <div class="col-xs-6 text-right">
                                <a href="javascript:void(0)" class="btn btn-main">
                                    <p style="margin-top:0.8rem;"><span class="icon icon-cart"></span> Checkout</p>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--/checkout-->
        </div>
        <!--/cart-wrapper-->

        <!-- <div class="cart-wrapper1">
        <input class="form-control" placeholder="Search..." />
            <button class="btn btn-main btn-search">Go!</button> 
        </div> -->
    </div>
    <!--/container-->
</nav><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/inc/header.blade.php ENDPATH**/ ?>