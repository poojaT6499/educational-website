

<?php $__env->startSection('content'); ?>

<section class="main-header" style="background-image:url(assets/images/productbanner.jpg)">
    <!-- <header class="hidden"> -->
        <div class="container text-center">
            <h1 class="h2 title">Rental Agreement</h1>
        </div>
    <!-- </header> -->
</section>

<!-- ========================  Products ======================== -->

<section class="products">
    <div class="container">

        <header>
            <div class="row">
                <div class=" col-md-offset-2 col-md-8 text-center">
                    <h2 class="title">Sample Rental Agreement</h2><br><br>
                    <div class="text">

                        <p>If your home or business requirement calls for a bulk order, Rentofurnish offers
                            turnkey services that cater to all needs: from setting up a new home, to furniture
                            for your office or business venture.
                        </p><br>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a
                            piece of classical Latin literature from 45 BC, making it over 2000 years old.
                            Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked
                            up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and
                            going through the cites of the word in classical literature, discovered the
                            undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de
                            Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45
                            BC. This book is a treatise on the theory of ethics, very popular during the
                            Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes
                            from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the
                            1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from
                            "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact
                            original form, accompanied by English versions from the 1914 translation by H.
                            Rackham.</p>


                    </div>
                </div>
            </div>
        </header>



    </div>
    <!--/container-->
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/layouts/rental.blade.php ENDPATH**/ ?>