<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>All Notifications</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('teacher')); ?>">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('teacher.notification')); ?>">Notifications</a></li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">All Notifications</h4>
                    <a href="<?php echo e(route('teacher.notification.create')); ?>" class="btn btn-primary">Create Notification</a>
                </div>
                <div class="card-body">
                    
                    
                    <div class="table-responsive">
                        <?php if(count($notifications)>0): ?>
                        <table id="example3" class="display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>
                                    <th>Class</th>
                                    <th>Message</th>
                                    <th>Date & Time</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i=1; ?>
                                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?> </td>
                                    <td>
                                        <?php
                                            foreach ($classes as $class) {
                                                if ($class->id == $notification->classes_id) {
                                        ?>
                                                    <?php echo e($class->name); ?>

                                        <?php
                                                }
                                            }
                                        ?>

                                    </td>
                                    <td>
                                        <?php echo e($notification->message); ?>

                                    </td>
                                    <td><?php echo e(date('d M, Y H:i A', strtotime($notification->created_at))); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('teacher.notification.delete', $notification)); ?>" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger"><i class="la la-trash-o"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <div class="alert alert-info" role="alert">
                            <strong>No Data Found!</strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/teacher/notification/index.blade.php ENDPATH**/ ?>