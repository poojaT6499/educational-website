<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>All Sessions</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('teacher')); ?>">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('teacher.session')); ?>">Sessions</a></li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">All Sessions</h4>
                    <a href="<?php echo e(route('teacher.session.create')); ?>" class="btn btn-primary">Create Session</a>
                </div>
                <div class="card-body">

                    <div class="table-responsive">
                        <?php if(count($sessions)>0): ?>
                        <table id="example3" class="display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>
                                    <th>Class & Subject</th>
                                    <th>Chapter</th>
                                    <th>Session Title</th>
                                    <th>Date & Time</th>
                                    <th>Link</th>
                                    <th>Type</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i=1; ?>
                                <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?> </td>
                                    <td>
                                        <?php
                                            $sub_id = 0;
                                            $class_id = 0;
                                            $sub_name = "";
                                            $class_name = "";
                                            foreach ($chapters as $chap){
                                                if($chap->id == $session->chapter_id)
                                                    $sub_id = $chap->subject_id;
                                            }
                                            foreach ($subjects as $sub) {
                                                if ($sub->id == $sub_id) {
                                                    $class_id = $sub->class_id;
                                                    $sub_name = $sub->name;
                                                }
                                            }
                                            foreach ($classes as $class) {
                                                if ($class->id == $class_id) {
                                                    $class_name = $class->name;
                                                }
                                            }
                                        ?>
                                        <?php echo e($class_name); ?> - <?php echo e($sub_name); ?>

                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($chap->id == $session->chapter_id): ?>
                                                <?php echo e($chap->name); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php echo e($session->title); ?>

                                    </td>
                                    <td><?php echo e(date('d M, Y H:i A', strtotime($session->schedule_time))); ?></td>
                                    <td>
                                        <a class="btn btn-primary" href="<?php echo e($session->link); ?>" target="_blank">Attend</a>
                                    </td>
                                    <td><?php echo e($session->type ? 'Doubts Session' : 'Live Session'); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('teacher.session.edit', $session)); ?>" class="btn btn-sm btn-warning"><i class="la la-pencil"></i></a>
                                        <a href="<?php echo e(route('teacher.session.delete', $session)); ?>" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger"><i class="la la-trash-o"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <div class="alert alert-info" role="alert">
                            <strong>No Data Found!</strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/teacher/session/index.blade.php ENDPATH**/ ?>