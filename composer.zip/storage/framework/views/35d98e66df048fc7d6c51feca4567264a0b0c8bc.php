

<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <div class="row">
        <div class="col-xl-6 col-xxl-12 col-sm-12">
            <div class="row">
                <div class="col-xl-6 col-xxl-6 col-sm-6">
                    <div class="widget-stat card">
                        <div class="card-body">
                            <h4 class="card-title">Total Classes</h4>
                            <h3>200</h3>
                            <div class="progress mb-2">
                                <div class="progress-bar progress-animated bg-primary" style="width: 80%"></div>
                            </div>
                            <small>80% Increase in 20 Days</small>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-xxl-6 col-sm-6">
                    <div class="widget-stat card">
                        <div class="card-body">
                            <h4 class="card-title">Total Chapters</h4>
                            <h3>245</h3>
                            <div class="progress mb-2">
                                <div class="progress-bar progress-animated bg-blue" style="width: 50%"></div>
                            </div>
                            <small>50% Increase in 25 Days</small>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="col-xl-6 col-xxl-12 col-sm-12">
            <div class="row">

                <div class="col-xl-6 col-xxl-6 col-sm-6">
                    <div class="widget-stat card">
                        <div class="card-body">
                            <h4 class="card-title">Total Courses</h4>
                            <h3>245</h3>
                            <div class="progress mb-2">
                                <div class="progress-bar progress-animated bg-red" style="width: 50%"></div>
                            </div>
                            <small>50% Increase in 25 Days</small>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 col-xxl-6 col-sm-6">
                    <div class="widget-stat card">
                        <div class="card-body">
                            <h4 class="card-title">Total Subscription Plan</h4>
                            <h3>3280</h3>
                            <div class="progress mb-2">
                                <div class="progress-bar progress-animated bg-success" style="width: 80%"></div>
                            </div>
                            <small>80% Increase in 20 Days</small>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php if(Session::has('status')): ?>
    <div class="alert alert-success">
        <strong><span class="glyphicon glyphicon-ok"></span><?php echo e(Session::get('status')); ?></strong>
    </div>
    <?php endif; ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Betawork\Manoj Academy\manojacademy\resources\views/admin/index.blade.php ENDPATH**/ ?>