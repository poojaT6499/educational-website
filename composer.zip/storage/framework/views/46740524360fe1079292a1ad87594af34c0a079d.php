<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Edit Teacher</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.teacher')); ?>">Teachers</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.teacher.create')); ?>">Edit Teacher</a></li>
            </ol>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-12 col-xxl-12 col-sm-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('admin.teacher.update', $teacher)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="name">Teacher Name:</label>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $teacher->name)); ?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name">Phone: <span class="text-muted text-small">(Optional)</span></label>
                                    <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone', $teacher->phone)); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name">Email:</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email', $teacher->email)); ?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="password">Password:</label>
                                    <input type="password" class="form-control" id="password" name="password" autocomplete="new-password" value="<?php echo e(old('password', $teacher->password)); ?>" required>
                                </div>
                            </div>
                            <input id="role" type="number" name="role" value="1" hidden>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<script>
// $(document).ready(function() {
//     console.log( "document loaded" );
// });
window.onload = function() {
    getChapters(1);
};

function removeOptions(selectElement) {
    var i, L = selectElement.options.length - 1;
    for(i = L; i >= 0; i--) {
        selectElement.remove(i);
    }
}

// using the function:
function getChapters(class_id) {
    var subjectsSelect = document.getElementById('subjects');
    removeOptions(subjectsSelect);
    $.ajax({
        type: 'GET',
        url: `<?php echo e(url('/admin/classes/${class_id}/getSubjects')); ?>`,
        data:'_token = <?php echo csrf_token() ?>',
        success: function(response) {
            var subjects = response.subjects;
            subjects.forEach(subject => {
                var subjectsSelect = document.getElementById('subjects');
                subjectsSelect.options[subjectsSelect.options.length] = new Option(subject.name, subject.id);
            });
            $(subjectsSelect).selectpicker('refresh');
        }
    });
};

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/admin/teacher/edit.blade.php ENDPATH**/ ?>