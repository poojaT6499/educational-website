
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>All Banner</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(Request::root()); ?>/admin/dashboard">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(Request::root()); ?>/admin/Banner">Banner</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(Request::root()); ?>/admin/Banner/add-Banner">Add
                        Banner</a>
                </li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <ul class="nav nav-pills mb-3">
                <li class="nav-item"><a href="#list-view" data-toggle="tab"
                        class="nav-link btn-primary mr-1 show active">List View</a></li>
                <li class="nav-item"><a href="#grid-view" data-toggle="tab" class="nav-link btn-primary">Grid View</a>
                </li>
            </ul>
        </div>
        <div class="col-lg-12">
            <div class="row tab-content">
                <div id="list-view" class="tab-pane fade active show col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">All Category </h4>
                            <a href="<?php echo e(Request::root()); ?>/admin/Banner/add-Banner" class="btn btn-primary">+ Add
                                new</a>
                        </div>
                        <div class="card-body">
                            <?php if(Session::has('message')): ?>
                            <div class="alert alert-success">
                                <strong><span class="glyphicon glyphicon-ok"></span><?php echo e(Session::get('message')); ?></strong>
                            </div>
                            <?php endif; ?>
                            <div class="table-responsive">
                                <?php if(count($Banners)>0): ?>
                                <table id="example3" class="display" style="min-width: 845px">
                                    <thead>
                                        <tr>
                                            <th>SL No</th>
                                            <th>image</th>
                                            <th>OrderNo</th>
                                            <th>Title</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i=1 ?>
                                        <?php $__currentLoopData = $Banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($i); ?> </td>
                                            <td>
                                                <img src="<?php echo e(asset('/uploads/').'/'. $Banner->BannerImg); ?>" width="100"
                                                    height="200" class="img-fluid rounded-circle" alt="">
                                            </td>
                                            <td><?php echo e($Banner->OrderNo); ?></td>
                                            <td><?php echo e(Str::substr($Banner->BannerTitle,0,30)); ?></td>

                                            <td>
                                                <a href="<?php echo e(Request::root()); ?>/admin/Banner/change-status-Banner/<?php echo e($Banner->BannerID); ?>"
                                                    class="btn btn-sm btn-warning"> <?php if($Banner->Status==1): ?>
                                                    <?php echo e("Activate"); ?> <?php else: ?> <?php echo e("Dectivate"); ?> <?php endif; ?> </a>

                                                <a href="<?php echo e(Request::root()); ?>/admin/Banner/edit-Banner/<?php echo e($Banner->BannerID); ?>"
                                                    class="btn btn-sm btn-primary"><i class="la la-pencil"></i></a>
                                                <a href="<?php echo e(Request::root()); ?>/admin/Banner/delete-Banner/<?php echo e($Banner->BannerID); ?>"
                                                    onclick="return confirm('are you sure to delete')"
                                                    class="btn btn-sm btn-danger"><i class="la la-trash-o"></i></a>
                                            </td>
                                        </tr>

                                        <?php $i++;  ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <?php else: ?>
                                <div class="alert alert-info" role="alert">
                                    <strong>No Plan Found!</strong>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="grid-view" class="tab-pane fade col-lg-12">
                    <div class="row">
                        <?php $__currentLoopData = $Banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="card card-profile">
                                <div class="card-header justify-content-end pb-0">
                                    <div class="dropdown">
                                        <button class="btn btn-link" type="button" data-toggle="dropdown">
                                            <span class="dropdown-dots fs--1"></span>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right border py-0">
                                            <div class="py-2">
                                                <a href="<?php echo e(Request::root()); ?>/admin/Banner/view-Banner/<?php echo e($Banner->BannerID); ?>"
                                                    class="ml-4"> <?php if($Banner->status==1): ?> <?php echo e("Activate"); ?> <?php else: ?>
                                                    <?php echo e("Dectivate"); ?> <?php endif; ?> </a>

                                                <a href="<?php echo e(Request::root()); ?>/admin/Banner/edit-Banner/<?php echo e($Banner->BannerID); ?>"
                                                    class="ml-4">Edit</a>
                                                <a href="<?php echo e(Request::root()); ?>/admin/Banner/delete-Banner/<?php echo e($Banner->BannerID); ?>"
                                                    onclick="return confirm('are you sure to delete')" class="ml-4">
                                                    Delete</a>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body pt-2">
                                    <div class="text-center">
                                        <div class="profile-photo">
                                            <img src="<?php echo e(asset('/uploads/').'/'. $Banner->BannerImg); ?>" width="100"
                                                height="200" class="img-fluid rounded-circle" alt="">
                                        </div>
                                        <h3 class="mt-4 mb-1"><?php echo e($Banner->BannerTitle); ?></h3>


                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\learningApp\resources\views/admin/banner/index.blade.php ENDPATH**/ ?>