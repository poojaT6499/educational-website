<div class="nav-header">
    <a href="javascript:void(0)" class="brand-logo">
        <h3 style="color:#fff; font-weight: 600;">Manoj Academy</h3>
        
        
        
    </a>
    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span><span class="line"></span><span class="line"></span>
        </div>
    </div>
</div>


<div class="header">
    <div class="header-content">
        <nav class="navbar navbar-expand">
            <div class="collapse navbar-collapse justify-content-between">
                <div class="header-left">
                    
                </div>
                <ul class="navbar-nav header-right">
                    <li class="nav-item dropdown notification_dropdown">
                        <a class="nav-link bell ai-icon" href="#" role="button" data-toggle="dropdown">
                            <svg id="icon-user" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                viewbox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell">
                                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                            </svg>
                            <div class="pulse-css"></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <ul class="list-unstyled">
                                <li class="media dropdown-item">
                                    <span class="success"><i class="ti-user"></i></span>
                                    <div class="media-body">
                                        <a href="#">
                                            <p><strong>Martin</strong> has added a <strong>customer</strong>
                                                Successfully
                                            </p>
                                        </a>
                                    </div>
                                    <span class="notify-time">3:20 am</span>
                                </li>
                                <li class="media dropdown-item">
                                    <span class="primary"><i class="ti-shopping-cart"></i></span>
                                    <div class="media-body">
                                        <a href="#">
                                            <p><strong>Jennifer</strong> purchased Light Dashboard 2.0.</p>
                                        </a>
                                    </div>
                                    <span class="notify-time">3:20 am</span>
                                </li>
                                <li class="media dropdown-item">
                                    <span class="danger"><i class="ti-bookmark"></i></span>
                                    <div class="media-body">
                                        <a href="#">
                                            <p><strong>Robin</strong> marked a <strong>ticket</strong> as
                                                unsolved.
                                            </p>
                                        </a>
                                    </div>
                                    <span class="notify-time">3:20 am</span>
                                </li>
                                <li class="media dropdown-item">
                                    <span class="primary"><i class="ti-heart"></i></span>
                                    <div class="media-body">
                                        <a href="#">
                                            <p><strong>David</strong> purchased Light Dashboard 1.0.</p>
                                        </a>
                                    </div>
                                    <span class="notify-time">3:20 am</span>
                                </li>
                                <li class="media dropdown-item">
                                    <span class="success"><i class="ti-image"></i></span>
                                    <div class="media-body">
                                        <a href="#">
                                            <p><strong> James.</strong> has added a<strong>customer</strong>
                                                Successfully
                                            </p>
                                        </a>
                                    </div>
                                    <span class="notify-time">3:20 am</span>
                                </li>
                            </ul>
                            <a class="all-notification" href="#">See all notifications <i
                                    class="ti-arrow-right"></i></a>
                        </div>
                    </li>
                    <li class="nav-item dropdown header-profile">
                        <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                            <img src="<?php echo e(asset('/admin/images/profile/education/pic1.jpg')); ?>" width="20" alt="">
                            <span> <?php if(Auth::guard('webadmin')->user()): ?>

                                <?php echo e(Auth::guard('webadmin')->user()->name); ?>



                                <?php endif; ?>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">

                            <a href="/logout" class="dropdown-item ai-icon"
                                onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                <svg id="icon-logout" xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                    viewbox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round" class="feather feather-log-out">
                                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                                    <polyline points="16 17 21 12 16 7"></polyline>
                                    <line x1="21" y1="12" x2="9" y2="12"></line>
                                </svg>
                                
                                <span>
                                    
                                    logout
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                        style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </span>
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>



<div class="dlabnav">
    <div class="dlabnav-scroll">
        <ul class="metismenu" id="menu">
            <li class="nav-label first">Main Menu</li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/dashboard" aria-expanded="false">
                    <i class="la la-home"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/Banner" aria-expanded="false">
                    <i class="la la-pencil"></i>
                    <span class="nav-text">Banners</span>
                </a>
            </li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/Classes" aria-expanded="false">
                    <i class="la la-user"></i>
                    <span class="nav-text">Classes</span>
                </a>
            </li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/Course" aria-expanded="false">
                    <i class="la la-shopping-cart"></i>
                    <span class="nav-text">Course</span>
                </a>
            </li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/Chapter" aria-expanded="false">
                    <i class="la la-flag"></i>
                    <span class="nav-text">Chapter</span>
                </a>
            </li>

            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/Media" aria-expanded="false">
                    <i class="la la-lightbulb-o"></i>
                    <span class="nav-text">Media</span>
                </a>
            </li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/question" aria-expanded="false">
                    <i class="la la-cart-plus"></i>
                    <span class="nav-text">Questions</span>
                </a>
            </li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/answer" aria-expanded="false">
                    <i class="la la-inr"></i>
                    <span class="nav-text">Answers</span>
                </a>
            </li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/questionandanswer" aria-expanded="false">
                    <i class="la la-anchor"></i>
                    <span class="nav-text">Question & Answer</span>
                </a>
            </li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/submission" aria-expanded="false">
                    <i class="la la-anchor"></i>
                    <span class="nav-text">Submission</span>
                </a>
            </li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/plan" aria-expanded="false">
                    <i class="la la-hourglass-half"></i>
                    <span class="nav-text">Subscription plan</span>
                </a>
            </li>
            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/livemeetings" aria-expanded="false">
                    <i class="la la-area-chart"></i>
                    <span class="nav-text">Live Meetings</span>
                </a>
            </li>



            <li><a class="has-arrow" href="<?php echo e(Request::root()); ?>/admin/notification" aria-expanded="false">
                    <i class="la la-gift"></i>
                    <span class="nav-text">Notification</span>
                </a>
            </li>

            <li><a class="has-arrow" href="/logout" aria-expanded="false">
                    <i class="la la-gift"></i>
                    <span class="nav-text">Logout</span>
                </a>

            </li>

        </ul>
    </div>
</div><?php /**PATH D:\xampp\htdocs\learningApp\resources\views/admin/inc/header.blade.php ENDPATH**/ ?>