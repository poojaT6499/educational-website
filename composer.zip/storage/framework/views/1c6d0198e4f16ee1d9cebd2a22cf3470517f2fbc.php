<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Edit Chapter</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('teacher')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="">Chapters</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('teacher.chapter.edit', [$class->id, $subject->id, $chapter->id])); ?>">Edit Chapter</a></li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12 col-xxl-12 col-sm-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-body">
                        <div class="mb-3">
                            <h4>Details</h4>
                        </div>
                        <form role="form" method="POST" action="<?php echo e(route('teacher.chapter.update', $chapter)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="text" value="<?php echo e($class->id); ?>" name="class_id" hidden>
                            <input type="text" value="<?php echo e($subject->id); ?>" name="subject_id" hidden>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <span class="text-muted">Class Name: </span> <p class="d-inline"><?php echo e($class->name); ?></p>
                                </div>
                                <div class="form-group col-md-4">
                                    <span class="text-muted">Subject Name: </span> <p class="d-inline"><?php echo e($subject->name); ?></p>
                                </div>
                                <div class="form-group col-md-4">
                                    
                                </div>
                            </div>
                            <hr>
                            <div class="mb-3">
                                <h4>Chapter Info</h4>
                                
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="name">Chapter Name:</label>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $chapter->name)); ?>">
                                </div>
                            </div>
                            <hr>
                            <div class="mb-3">
                                <h4>Video Details</h4>
                                
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group col-md-12">
                                        <label for="media_title">Video Title:</label>
                                        <input type="text" class="form-control" id="media_title" name="media_title" value="<?php echo e(old('media_title', $media ? $media->title : '' )); ?>">
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label for="video">Replace Video:</label>
                                        <input type="file" class="form-control" id="video" name="video">
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label for="is_demo">Is It Demo Video </label>
                                        <input type="checkbox" name="is_demo" <?php echo e($media ?  $media->is_demo == 1 ? 'checked' : '' : ''); ?>>
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="video">Your Video:</label>
                                    <?php if($media): ?>
                                    <video width="100%" controls>
                                        <source src="<?php echo e($media->media_url); ?>" type="video/<?php echo e($media->media_type); ?>">
                                        Your browser does not support the video tag.
                                    </video>
                                    <?php else: ?>
                                        <p>No Media Found</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <hr>
                            <div class="mb-3">
                                <h4>Attach Notes/Assignments</h4>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="notes">Add Files:</label>
                                        <input type="file" class="form-control" id="notes" name="notes[]" multiple>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="notes">Your Files:</label>
                                        <?php if($notes->count()): ?>
                                            <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e($note->file); ?>" class="d-block" target="_blank" style="text-decoration: underline;">View file.<?php echo e($note->type); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <p>No Files Found</p>
                                        <?php endif; ?>

                                        
                                    </div>
                                </div>
                            </div>

                            <br>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/teacher/chapter/edit.blade.php ENDPATH**/ ?>