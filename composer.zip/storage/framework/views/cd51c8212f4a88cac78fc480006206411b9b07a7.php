<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>All Chapters</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('teacher')); ?>">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('teacher.chapter')); ?>">Chapter</a></li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">All Chapters</h4>
                    
                    <a href="<?php echo e(route('teacher.chapter.create', [$class->id, $subject->id])); ?>" class="btn btn-primary">Add Chapter</a>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <span class="text-muted">Class Name: </span> <p class="d-inline"><?php echo e($class->name); ?></p>
                        </div>
                        <div class="form-group col-md-4">
                            <span class="text-muted">Subject Name: </span> <p class="d-inline"><?php echo e($subject->name); ?></p>
                        </div>
                        
                    </div>
                    <hr>
                    <?php if(Session::has('message')): ?>
                    <div class="alert alert-success">
                        <strong><span class="glyphicon glyphicon-ok"></span><?php echo e(Session::get('message')); ?></strong>
                    </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <?php if(count($chapters)>0): ?>
                        <table id="example3" class="display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>
                                    <th>Chapter Name</th>
                                    <th>Video Title</th>
                                    <th>Video</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i=1;
                                    $j=0;
                                ?>
                                <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <tr>
                                    <td><?php echo e($i); ?> </td>
                                    <td><?php echo e($chapter->name); ?></td>
                                    <td>
                                        <?php if($medias->count()): ?>
                                        <?php echo e($medias[$j]->title); ?>

                                        <?php else: ?>
                                            No Media Found
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($medias->count()): ?>
                                        <video width="220" height="140" controls>
                                            <source src="<?php echo e($medias[$j]->media_url); ?>" type="video/<?php echo e($medias[$j]->media_type); ?>">
                                            Your browser does not support the video tag.
                                        </video>
                                        <?php else: ?>
                                            No Media Found
                                        <?php endif; ?>

                                    </td>
                                    <td><?php echo e($chapter->status ? 'Published' : 'Pending For Approval'); ?></td>
                                    <td>
                                        
                                        <a href="<?php echo e(route('teacher.chapter.edit', [$class, $subject, $chapter])); ?>" class="btn btn-sm btn-warning"><i class="la la-pencil"></i></a>
                                        <a href="<?php echo e(route('teacher.chapter.delete', $chapter)); ?>" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger"><i class="la la-trash-o"></i></a>
                                    </td>
                                </tr>

                                <?php
                                    $i++;
                                    $j++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php else: ?>
                        <div class="alert alert-info" role="alert">
                            <strong>No Plan Found!</strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/teacher/chapter/index.blade.php ENDPATH**/ ?>