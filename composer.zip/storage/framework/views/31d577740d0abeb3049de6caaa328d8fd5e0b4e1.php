<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>All Questions</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('teacher')); ?>">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('teacher.question')); ?>">Questions</a></li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">All Questions</h4>
                    <a href="<?php echo e(route('teacher.question.create')); ?>" class="btn btn-primary">Add Question</a>
                </div>
                <div class="card-body">
                    
                    
                    <div class="table-responsive">
                        <?php if(count($questions)>0): ?>
                        <table id="example3" class="display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>
                                    <th>Chapter Name</th>
                                    <th>Question</th>
                                    <th>Marks</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i=1; ?>
                                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?> </td>
                                    <td>
                                        <?php
                                            $chap_name = '';
                                            foreach ($chapters as $chap) {
                                                if($question->chapter_id == $chap->id) {
                                        ?>
                                            <?php echo e($chap->name); ?>

                                        <?php
                                                }
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo e($question->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($question->marks); ?>

                                    </td>
                                    <td>
                                        <?php echo e($question->type ? 'MCQ' : 'Written'); ?>

                                    </td>
                                    <td><?php echo e($question->status ? 'Published' : 'Pending For Approval'); ?></td>
                                    <td>
                                        
                                        <a href="<?php echo e(route('teacher.question.edit', $question)); ?>" class="btn btn-sm btn-warning"><i class="la la-pencil"></i></a>
                                        <a href="<?php echo e(route('teacher.question.delete', $question)); ?>" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger"><i class="la la-trash-o"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <div class="alert alert-info" role="alert">
                            <strong>No Data Found!</strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/teacher/question/index.blade.php ENDPATH**/ ?>