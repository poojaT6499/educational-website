<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>All Tests</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('teacher')); ?>">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('teacher.test')); ?>">Test</a></li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">All Tests</h4>
                    <a href="<?php echo e(route('teacher.test.create')); ?>" class="btn btn-primary">Add Test</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <?php if(count($tests)>0): ?>
                        <table id="example3" class="display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>
                                    <th>Class & Subject</th>
                                    <th>Title</th>
                                    <th>Total Marks</th>
                                    <th>Duration</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i=1;
                                    $j=0;
                                ?>
                                <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i); ?> </td>
                                    <td>
                                        <?php
                                            $sub_id = $test->subject_id;
                                            $class_id = 0;
                                            $sub_name = "";
                                            $class_name = "";

                                            foreach ($subjects as $sub) {
                                                if ($sub->id == $sub_id) {
                                                    $class_id = $sub->class_id;
                                                    $sub_name = $sub->name;
                                                }
                                            }
                                            foreach ($classes as $class) {
                                                if ($class->id == $class_id) {
                                                    $class_name = $class->name;
                                                }
                                            }
                                        ?>
                                        <?php echo e($class_name); ?> - <?php echo e($sub_name); ?>

                                    </td>
                                    <td><?php echo e($test->title); ?></td>
                                    <td><?php echo e($test->total_marks); ?></td>
                                    <td><?php echo e($test->duration); ?></td>
                                    
                                    <td>
                                        <a href="<?php echo e(route('teacher.test.edit', $test)); ?>" class="btn btn-sm btn-warning"><i class="la la-pencil"></i></a>
                                        <a href="" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger"><i class="la la-trash-o"></i></a>
                                    </td>
                                </tr>

                                <?php
                                    $i++;
                                    $j++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php else: ?>
                        <div class="alert alert-info" role="alert">
                            <strong>No Data Found!</strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Betawork\Manoj Academy\manoj-academy\resources\views/teacher/test/index.blade.php ENDPATH**/ ?>