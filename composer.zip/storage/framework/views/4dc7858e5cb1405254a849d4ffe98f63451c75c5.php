

<?php $__env->startSection('content'); ?>

<section></section>

        <section class="products">
            <div class=" container">
                <header>
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8 text-center">
                            <h2 class="title">All the furniture you can take.<br>One Price.</h2>
                        </div>
                    </div>
                </header>
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <article class="offer">
                            <div class="card">
                                <div class="card-body" style="padding: 2rem;">
                                    <h2 class="card-title">basic </h2>
                                    <h5>6 Products</h5>
                                    <div class="price">
                                        <span class="h3">
                                            ₹ 1999,00
                                        </span>
                                        <span>/Monthly</span>
                                    </div>
                                    <div class="price">
                                        <small>₹ 2999,00 </small>
                                        <span> /Monthly</span>
                                    </div><br>
                                    <div>
                                        <ul style="list-style: disc">
                                            <li>Access to 80+ products</li>
                                            <li>Billed annually</li>
                                            <li>No cost EMI options available</li>
                                            <li>15-days window to swap products</li>
                                            <li>Free Relocation</li>
                                        </ul>
                                    </div>

                                    <div class="wrapper-more">
                                        <a href="plans-product.php" class="btn btn-main">
                                            <p style="margin: 1rem;">Select Plan</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <article class="offer">
                            <div class="card">
                                <div class="card-body" style="padding: 2rem;">
                                    <h2 class="card-title">basic </h2>
                                    <h5>6 Products</h5>
                                    <div class="price">
                                        <span class="h3">
                                            ₹ 1999,00
                                        </span>
                                        <span>/Monthly</span>
                                    </div>
                                    <div class="price">
                                        <small>₹ 2999,00 </small>
                                        <span> /Monthly</span>
                                    </div><br>
                                    <div>
                                        <ul style="list-style: disc">
                                            <li>Access to 80+ products</li>
                                            <li>Billed annually</li>
                                            <li>No cost EMI options available</li>
                                            <li>15-days window to swap products</li>
                                            <li>Free Relocation</li>
                                        </ul>
                                    </div>

                                    <div class="wrapper-more">
                                        <a href="plans-product.php" class="btn btn-main">
                                            <p style="margin: 1rem;">Select Plan</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <article class="offer">
                            <div class="card">
                                <div class="card-body" style="padding: 2rem;">
                                    <h2 class="card-title">basic </h2>
                                    <h5>6 Products</h5>
                                    <div class="price">
                                        <span class="h3">
                                            ₹ 1999,00
                                        </span>
                                        <span>/Monthly</span>
                                    </div>
                                    <div class="price">
                                        <small>₹ 2999,00 </small>
                                        <span> /Monthly</span>
                                    </div><br>
                                    <div>
                                        <ul style="list-style: disc">
                                            <li>Access to 80+ products</li>
                                            <li>Billed annually</li>
                                            <li>No cost EMI options available</li>
                                            <li>15-days window to swap products</li>
                                            <li>Free Relocation</li>
                                        </ul>
                                    </div>
                                    <div class="wrapper-more">
                                        <a href="plans-product.php" class="btn btn-main">
                                            <p style="margin: 1rem;">Select Plan</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- ======================== Products ======================== -->

        <section class="products">
            <div class="container">

                <header class="hidden">
                    <h3 class="h3 title">Product category grid</h3>
                </header>

                <div class="row">



                </div>



            </div>

        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/layouts/plans.blade.php ENDPATH**/ ?>