

<?php $__env->startSection('content'); ?>
<section class="main-header" style="background-image:url(assets/images/productbanner.jpg)">
    <header>
        <div class="container text-center">
            <h2 class="h2 title">User profile</h2>
            <ol class="breadcrumb breadcrumb-inverted">
                <li><a href="index.php"><span class="icon icon-home"></span></a></li>
                <li><a class="active" href="profile.php">USER</a></li>
            </ol>
        </div>
    </header>
</section>

<!-- ========================  Login & register ======================== -->
<section class="checkout cart">
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-3 pb-5">
                <!-- Account Sidebar-->
                <div class="author-card pb-3">

                    <div class="author-card-profile">
                        <div class="author-card-avatar"><img
                                src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="Daniel Adams">
                        </div>
                        <div class="author-card-details">
                            <h5 class="author-card-name text-lg">Daniel Adams</h5>
                            <!-- <span
                                class="author-card-position">Joined February 06, 2017</span> -->
                        </div>
                    </div>
                </div>
                <div class="wizard">
                    <nav class="list-group list-group-flush group-item" style="position: static!important;">
                        <a class="list-group-item " data-toggle="tab" href="#profile">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="d-inline-block font-weight-medium text-uppercase"
                                        style="font-size: 1.4rem;"><i class="fa fa-user"
                                            aria-hidden="true"></i>Profile
                                    </div>
                                </div>
                                <!-- <span class="badge badge-secondary">6</span> -->
                            </div>
                        </a>
                        <a class="list-group-item" data-toggle="tab" href="#address"
                            style="font-size: 1.4rem;"><i class="fa fa-map-marker" aria-hidden="true"></i>
                            ADDRESS</a>
                        <a class="list-group-item" data-toggle="tab" href="#order" style="font-size: 1.4rem;"><i
                                class="fa fa-archive" aria-hidden="true"></i> Order List</a>
                        <a class="list-group-item" data-toggle="tab" href="#cart" style="font-size: 1.4rem;"><i
                                class="fa fa-shopping-cart" aria-hidden="true"></i>My Cart</a>
                        <a class="list-group-item" href="#wishlist" data-toggle="tab" target="__blank"
                            style="font-size: 1.4rem;">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>

                                    <div class="d-inline-block font-weight-medium text-uppercase"><i
                                            class="fa fa-heart" aria-hidden="true"></i>My Wishlist
                                    </div>
                                </div>
                                <!-- <span class="badge badge-secondary">3</span> -->
                            </div>
                        </a>
                        <a class="list-group-item" href="#" target="__blank" style="font-size: 1.4rem;">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="d-inline-block font-weight-medium text-uppercase"><i
                                            class="fa fa-user" aria-hidden="true"></i>Logout
                                    </div>
                                </div>
                                <!-- <span class="badge badge-secondary">4</span> -->
                            </div>
                        </a>
                    </nav>
                </div>
            </div>
            <!-- Profile Settings-->
            <div class="tab-content col-lg-9 pb-5">

                <div id="profile" class="tab-pane fade in active">
                    <h4>Profile</h4>
                    <form class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="account-fn">First Name</label>
                                <input class="form-control" type="text" id="account-fn" value="Daniel"
                                    required="">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="account-email">E-mail Address</label>
                                <input class="form-control" type="email" id="account-email"
                                    value="daniel.adams@example.com" disabled="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="account-phone">Phone Number</label>
                                <input class="form-control" type="text" id="account-phone"
                                    value="+7 (805) 348 95 72" required="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="account-pass">Pincode</label>
                                <input class="form-control" type="text" id="" value="487456">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="account-confirm-pass">Address</label>
                                <textarea class="form-control" type="text" id="" value="malad"></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="account-pass">Password</label>
                                <input class="form-control" type="password" id="account-pass" value="12345"
                                    required="">
                            </div>
                        </div>

                        <div class="col-md-12">
                            <!-- <hr class="mt-2 mb-3"> -->
                            <div class="form-group">
                                <!-- <div class="custom-control custom-checkbox d-block">
                                <input class="custom-control-input" type="checkbox" id="subscribe_me"
                                    checked="">

                            </div> -->
                                <button class="btn3 btn btn-main" type="button" data-toast=""
                                    onclick="toastFunction()" style="float: right;"><i class="fa fa-pencil"
                                        aria-hidden="true" style="margin-right: 1rem;"></i>Update</button>

                                <div id="toast">
                                    <div class="checkicon"> <i class="fa fa-check-circle-o" aria-hidden="true"
                                            style="color:green;"></i> </div>
                                    Profile Updated Successfully!
                                </div>
                                <!-- <div id="myAlert">
                                    <div class="myAlert-text-icon">
                                        <div class="myAlert-message">
                                            Updated Successfully!
                                        </div>
                                        <button class="close" onclick="hideAlert()">
                                            <i class='bx bx-x'></i>
                                        </button>
                                    </div>
                                    <div id="myAlertProgress">
                                        <div id="myAlertBar"></div>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </form>

                    <script>
                        function showAlert() {
                            var myAlert = document.getElementById("myAlert");
                            move();
                            myAlert.className = "show";
                            setTimeout(function () {
                                hideAlert();
                            }, 3000);
                        }

                        function hideAlert() {
                            myAlert.className = myAlert.className.replace("show", "");
                        }
                        var i = 0;

                        function move() {
                            if (i == 0) {
                                var elem = document.getElementById("myAlertBar");
                                var width = 1;
                                var interval = setInterval(frame, 100);

                                function frame() {
                                    if (width >= 100) {
                                        clearInterval(id);
                                        interval = 0;
                                    } else {
                                        width++;
                                        elem.style.width = width + "%";
                                    }
                                }
                            }
                        }
                    </script>
                </div>
                <div id="address" class="tab-pane fade in">
                    <h4>Address</h4>
                    <form class="row">

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="account-confirm-pass">Add a new address</label>
                                <textarea class="form-control" type="text" id="" value="malad"></textarea>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <h5> Choose Delivery Address</h5>
                            <span class="checkbox">
                                <input type="checkbox" id="checkBoxId3">
                                <label for="checkBoxId3">wgwergwerg Mumbai
                                    Maharashtra - 400099</label>
                            </span>
                        </div>
                        <div class="col-md-12">
                            <span class="checkbox">
                                <input type="checkbox" id="checkBoxId4">
                                <label for="checkBoxId4">bggvbsdbfbfs sdbddfb Mumbai
                                    Maharashtra - 400098</label>
                            </span>
                        </div>



                        <div class="col-md-12">
                            <div class="form-group">

                                <button class="btn3 btn btn-main" type="button" data-toast=""
                                    style="float: right;">continue</button>

                                <!-- <div id="toast">
                                    <div class="checkicon"> <i class="fa fa-check-circle-o" aria-hidden="true"
                                            style="color:green;"></i> </div>
                                    Profile Updated Successfully!
                                </div> -->

                            </div>
                        </div>
                    </form>


                </div>
                <div id="order" class="tab-pane fade in">
                    <h4>Order list</h4>
                    <div class="cart-wrapper">

                        <!--cart header -->

                        <div class="cart-block cart-block-header clearfix">
                            <div>
                                <span>Product</span>
                            </div>
                            <div>
                                <span>&nbsp;</span>
                            </div>
                            <div>
                                <span>Quantity</span>
                            </div>
                            <div class="text-right">
                                <span>Price</span>
                            </div>
                        </div>

                        <!--cart items-->

                        <div class="clearfix">
                            <div class="cart-block cart-block-item clearfix">
                                <div class="image">
                                    <a href="product.php"><img src="assets/images/chair3.jpg" alt="" /></a>
                                </div>
                                <div class="title">
                                    <div class="h4"><a href="product.php">Green corner</a></div>
                                    <div>Green corner</div>
                                </div>
                                <div class="quantity">
                                    <div class="value-button minus" id="decrease" onclick="decreaseValue4()"
                                        value="Decrease Value">-</div>
                                    <input class="num" type="number" id="number4" value="0" />
                                    <div class="value-button plus" id="increase" onclick="increaseValue4()"
                                        value="Increase Value">+</div>
                                </div>
                                <div class="price">
                                    <span class="final h3">₹ 1.998</span>
                                    <span class="discount">₹ 2.666</span>
                                </div>
                                <!--delete-this-item-->
                                <span class="icon icon-cross icon-delete"></span>
                            </div>
                            <div class="cart-block cart-block-item clearfix">
                                <div class="image">
                                    <a href="product.php"><img src="assets/images/chair3.jpg" alt="" /></a>
                                </div>
                                <div class="title">
                                    <div class="h4"><a href="product.php">Green corner</a></div>
                                    <div>Green corner</div>
                                </div>
                                <div class="quantity">
                                    <div class="value-button minus" id="decrease" onclick="decreaseValue5()"
                                        value="Decrease Value">-</div>
                                    <input class="num" type="number" id="number5" value="0" />
                                    <div class="value-button plus" id="increase" onclick="increaseValue5()"
                                        value="Increase Value">+</div>
                                </div>
                                <div class="price">
                                    <span class="final h3">₹ 1.998</span>
                                    <span class="discount">₹ 2.666</span>
                                </div>
                                <!--delete-this-item-->
                                <span class="icon icon-cross icon-delete"></span>
                            </div>
                            <!-- <div class="col-md-12" style="padding-top: 2rem;">
                                <div class="form-group">
                                    <a href="checkout-1.php" class="btn btn-main" style="float: right;">
                                        <p class="para"><span class="icon icon-chevron-left"></span> checkout
                                        </p>
                                    </a>

                                </div>

                            </div> -->


                        </div>
                    </div>
                </div>
                <div id="cart" class="tab-pane fade in">
                    <h4>My Cart</h4>
                    <div class="cart-wrapper">
                        <!--cart header -->

                        <div class="cart-block cart-block-header clearfix">
                            <div>
                                <span>Product</span>
                            </div>
                            <div>
                                <span>&nbsp;</span>
                            </div>
                            <div>
                                <span>Quantity</span>
                            </div>
                            <div class="text-right">
                                <span>Price</span>
                            </div>
                        </div>

                        <!--cart items-->

                        <div class="clearfix">
                            <div class="cart-block cart-block-item clearfix">
                                <div class="image">
                                    <a href="product.php"><img src="assets/images/chair3.jpg" alt="" /></a>
                                </div>
                                <div class="title">
                                    <div class="h4"><a href="product.php">Green corner</a></div>
                                    <div>Green corner</div>
                                </div>
                                <div class="quantity">
                                    <div class="value-button minus" id="decrease" onclick="decreaseValue6()"
                                        value="Decrease Value">-</div>
                                    <input class="num" type="number" id="number6" value="0" />
                                    <div class="value-button plus" id="increase" onclick="increaseValue6()"
                                        value="Increase Value">+</div>
                                </div>
                                <div class="price">
                                    <span class="final h3">₹ 1.998</span>
                                    <span class="discount">₹ 2.666</span>
                                </div>
                                <!--delete-this-item-->
                                <span class="icon icon-cross icon-delete"></span>
                            </div>
                            <div class="cart-block cart-block-item clearfix">
                                <div class="image">
                                    <a href="product.php"><img src="assets/images/chair3.jpg" alt="" /></a>
                                </div>
                                <div class="title">
                                    <div class="h4"><a href="product.php">Green corner</a></div>
                                    <div>Green corner</div>
                                </div>
                                <div class="quantity">
                                    <div class="value-button minus" id="decrease" onclick="decreaseValue7()"
                                        value="Decrease Value">-</div>
                                    <input class="num" type="number" id="number7" value="0" />
                                    <div class="value-button plus" id="increase" onclick="increaseValue7()"
                                        value="Increase Value">+</div>
                                </div>
                                <div class="price">
                                    <span class="final h3">₹ 1.998</span>
                                    <span class="discount">₹ 2.666</span>
                                </div>
                                <!--delete-this-item-->
                                <span class="icon icon-cross icon-delete"></span>
                            </div>
                            <div class="col-md-12" style="padding-top: 2rem;">
                                <div class="form-group">
                                    <a href="checkout.php" class="btn btn-main" style="float: right;">
                                        <p class="para"><span class="icon icon-chevron-left"></span> checkout
                                        </p>
                                    </a>

                                </div>

                            </div>


                        </div>
                    </div>
                </div>
                <div id="wishlist" class="tab-pane fade in">
                    <h4>Wishlist</h4>
                    <div class="cart-wrapper">
                        <!--cart header -->

                        <div class="cart-block cart-block-header clearfix">
                            <div>
                                <span>Product</span>
                            </div>
                            <div>
                                <span>&nbsp;</span>
                            </div>
                            <div>
                                <span>Quantity</span>
                            </div>
                            <div class="text-right">
                                <span>Price</span>
                            </div>
                        </div>

                        <!--cart items-->

                        <div class="clearfix">
                            <div class="cart-block cart-block-item clearfix">
                                <div class="image">
                                    <a href="product.php"><img src="assets/images/chair3.jpg" alt="" /></a>
                                </div>
                                <div class="title">
                                    <div class="h4"><a href="product.php">Green corner</a></div>
                                    <div>Green corner</div>
                                </div>
                                <div class="quantity">
                                    <div class="value-button minus" id="decrease" onclick="decreaseValue8()"
                                        value="Decrease Value">-</div>
                                    <input class="num" type="number" id="number8" value="0" />
                                    <div class="value-button plus" id="increase" onclick="increaseValue8()"
                                        value="Increase Value">+</div>
                                </div>
                                <div class="price">
                                    <span class="final h3">Rs 1.998</span>
                                    <span class="discount">Rs 2.666</span>
                                </div>
                                <!--delete-this-item-->
                                <span class="icon icon-cross icon-delete"></span>
                            </div>
                            <div class="cart-block cart-block-item clearfix">
                                <div class="image">
                                    <a href="product.php"><img src="assets/images/chair3.jpg" alt="" /></a>
                                </div>
                                <div class="title">
                                    <div class="h4"><a href="product.php">Green corner</a></div>
                                    <div>Green corner</div>
                                </div>
                                <div class="quantity">
                                    <div class="value-button minus" id="decrease" onclick="decreaseValue9()"
                                        value="Decrease Value">-</div>
                                    <input class="num" type="number" id="number9" value="0" />
                                    <div class="value-button plus" id="increase" onclick="increaseValue9()"
                                        value="Increase Value">+</div>
                                </div>
                                <div class="price">
                                    <span class="final h3">Rs 1.998</span>
                                    <span class="discount">Rs 2.666</span>
                                </div>
                                <!--delete-this-item-->
                                <span class="icon icon-cross icon-delete"></span>
                            </div>
                            <div class="col-md-12" style="padding-top: 2rem;">
                                <div class="">
                                    <a href="" class="btn btn-main" onclick="toastFunction()"
                                        style="float: right; width: 15rem;">
                                        <p class="para"><span class="icon icon-cart"></span> Add to Cart</p>
                                    </a>

                                </div>
                                <div id="toast">
                                    <div class="checkicon"> <i class="fa fa-check-circle-o" aria-hidden="true"
                                            style="color:green;"></i> </div>
                                    Item added successfully in cart!
                                </div>

                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<script>
    function toastFunction() {
        var x = document.getElementById("toast");
        x.className = "show";
        setTimeout(function () {
            x.className = x.className.replace("show", "");
        }, 3000);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/layouts/profile.blade.php ENDPATH**/ ?>