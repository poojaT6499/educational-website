

<?php $__env->startSection('content'); ?>

<section class="main-header" style="background-image:url(assets/images/products1.jpg);opacity:0.8;">
    <header>
        <div class="container">
            <h1 class="h2 title">Sofa </h1>
            <ol class="breadcrumb breadcrumb-inverted">
                <li><a href="index.php"><span class="icon icon-home"></span></a></li>
                <li><a href="products-grid.php
                ">Product Category</a></li>
                <!-- <li><a href="products-grid.php
                ">Product Sub-category</a></li> -->
                <li><a class="active" href="product.php
                ">Product overview</a></li>
            </ol>
        </div>
    </header>
</section>

<!-- ========================  Product ======================== -->

<!-- <div class="container">
    <div style="float: right;">
        <a href="contact.php">Need help?</a>
    </div>
</div> -->

<section class="product">
    <div class="main">
        <div class="container">
            <!-- <div style="float: right;">
                <a href="contact.php">Need help?</a>
            </div> -->
            <div class="row product-flex">

                <!-- product flex is used only for mobile order -->
                <!-- on mobile 'product-flex-info' goes bellow gallery 'product-flex-gallery' -->

                <div class="col-md-4 col-sm-12 product-flex-info">
                    <div class="clearfix">

                        <!-- === product-title === -->

                        <h1 class="title" data-title="">Laura <small>La Linea de Lucco</small></h1>

                        <div class="clearfix">

                            <!-- === price wrapper === -->

                            <div class="price">
                                <span class="h3">
                                    ₹ 1999,00

                                </span>
                                <span>Monthly Rental</span>

                            </div>
                            <div class="price">

                                <small>₹ 2999,00 </small>
                                <span> save ₹.1000 every month</span>
                            </div>
                            <hr />

                            <div class="">
                                <span>Refundable Security Deposit</span>
                                <strong>₹ 1800</strong>
                            </div>
                            <hr />



                            <div class="">
                                <span>Free delivery in</span>
                                <strong>72 hours</strong>
                            </div>
                            <hr />




                            <!-- === info-box === -->

                            <div class="info-box">
                                <span><strong>Available Colors</strong></span>
                                <div class="product-colors clearfix">
                                    <span class="color-btn color-btn-red"></span>
                                    <span class="color-btn color-btn-blue checked"></span>
                                    <span class="color-btn color-btn-green"></span>
                                    <span class="color-btn color-btn-gray"></span>
                                    <span class="color-btn color-btn-biege"></span>
                                </div>
                            </div>



                        </div>
                        <!--/clearfix-->
                    </div>
                    <!--/product-info-wrapper-->
                </div>
                <!--/col-md-4-->
                <!-- === product item gallery === -->


                <div class="col-md-8 col-sm-12 product-flex-gallery">
                    <!-- === add to cart === -->

                    <button type="submit" class="btn btn-buy cartbtn" data-text="Rent"></button>




                    <!-- === product gallery === -->

                    <div class="owl-product-gallery open-popup-gallery">
                        <a href="assets/images/couch.jpg"><img class="imgw" src="assets/images/couch.jpg" alt=""
                                height="500" /></a>
                        <a href="assets/images/couch.jpg"><img class="imgw" src="assets/images/couch.jpg" alt=""
                                height="500" /></a>
                        <a href="assets/images/couch.jpg"><img class="imgw" src="assets/images/couch.jpg" alt=""
                                height="500" /></a>
                        <a href="assets/images/couch.jpg"><img class="imgw" src="assets/images/couch.jpg" alt=""
                                height="500" /></a>
                    </div>
                    <!-- <button type="submit" class="btn btn-buy" data-text=""></button> -->
                </div>

            </div>
        </div>
    </div>

    <section>
        <div class="container">
            <div class="col-md-12">
                <a href="products-grid.php"><button type="submit" class="btn btn-buy"
                        data-text="add"></button></a>
                <h4>Item Included</h4>
                <ul class="nav nav-tabs col-md-4" role="tablist">
                    <li role="presentation" class="active">
                        <a href="#basic" aria-controls="basic" role="tab" data-toggle="tab">

                            <strong>Basic<br><span>₹ 1000</span></strong>
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#value" aria-controls="value" role="tab" data-toggle="tab">

                            <strong>Primium<br><span>₹ 1000</span></strong>
                        </a>
                    </li>
                    <!-- <li role="presentation">
                    <a href="#prime" aria-controls="prime" role="tab" data-toggle="tab">
                        <strong>Prime<br><span>Rs.1000</span></strong>
                    </a>
                </li> -->
                </ul>

                <!-- === tab-panes === -->

                <div class="tab-content col-md-8">

                    <div role="tabpanel" class="tab-pane active" id="basic">
                        <div class="tile-items d-flex flex-column">

                            <div class="tile-items-heading pd2">Package Includes : 1 ITEM</div>
                            <div class="d-flex">
                                <div
                                    class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                    <div class=" d-flex justify-content-center align-items-center">
                                        <img src="assets/images/Queen_Bed.jpg"
                                            itemprop="image" width="100%"></div>

                                </div>

                            </div>
                        </div>
                        <!--/content-->
                    </div>
                    <!--/tab-pane-->
                    <!-- ============ tab #2 ============ -->

                    <div role="tabpanel" class="tab-pane" id="value">
                        <div class=" tile-items d-flex flex-column">

                            <div class="tile-items-heading pd2">Package Includes : 2 ITEMS</div>
                            <div class="d-flex">
                                <div
                                    class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                    <div class=" d-flex justify-content-center align-items-center">
                                        <img src="assets/images/Queen_Bed.jpg"
                                            itemprop="image" width="100%"></div>

                                </div>
                                <div
                                    class="tile-item d-flex flex-column justify-content-center align-items-center margin-r-s col-md-4 col-xs-6">
                                    <div class=" d-flex justify-content-center align-items-center">
                                        <img src="assets/images/Queen_Bed.jpg"
                                            itemprop="image" width="100%"></div>

                                </div>

                            </div>
                        </div>
                        <!--/content-->
                    </div>


                </div>

            </div>





        </div>
    </section>
    <section>
        <div class="container margin-tb-l padding-l-0 bg-white condition">

            <div class="container margin-tb-l padding-tb-l padding-l-0 bg-white condition">
                <div class="row pd5">
                    <div class="col-md-2 col-xs-6 procondition">
                        <div
                            class="condition-strip position-relative d-flex justify-content-center align-items-center mint">
                            <span style="font-weight: bold;">Product Condition</span>
                            <div class="condition-strip__arrow condition-strip__arrow--top"></div>
                            <div class="condition-strip__arrow condition-strip__arrow--bottom"></div>
                        </div>
                    </div>
                    <div class="col-md-10 col-xs-6 font-weight-light">Packages delivered to you are as good as
                        new.
                        In fact,
                        they are better than new.They are restored to their original condition and
                        subjected to rigorous quality tests before shipment.</div>
                </div>
            </div>
        </div>
    </section>

    <!-- === product-info === -->

    <div class="info">
        <div class="container">
            <h4 class="photo">What’s Included In The Package</h4>
            <div class="row">

                <!-- === product-designer === -->

                <div class="col-md-4">
                    <div class="designer">
                        <div class="box">
                            <div class="image">
                                <img src="assets\images\couch4.jpg" alt="Alternate Text" />
                            </div>

                        </div>

                    </div>

                </div>


                <div class="col-md-8">
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active">
                            <a href="#designer" aria-controls="designer" role="tab" data-toggle="tab">
                                <i class="icon icon-user"></i>
                                <span>Collection</span>
                            </a>
                        </li>
                        <li role="presentation">
                            <a href="#design" aria-controls="design" role="tab" data-toggle="tab">
                                <i class="icon icon-sort-alpha-asc"></i>
                                <span>Specification</span>
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active" id="designer">
                            <div class="content">
                                <h3>Spring Mattress 6"</h3>
                                <p>Spring mattresses sandwich balanced layers of foam and spring that enriches
                                    your sleep quality. Quilted cover along with multiple layers of comfort foam
                                    elevates your sleeping experience. *The color of the mattress may vary from
                                    the image.*</p>
                                <strong>Quantity:<spam>1 unit</spam></strong>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane" id="design">
                            <div class="content">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="d-flex scale">
                                            <img src="assets/images/ruler.png" alt="" width=30px
                                                style="margin-right: 2rem;">
                                            <div>
                                                198.12 cm x 152.4 cm x 15.24 cm
                                            </div>
                                        </div>
                                        <div class=" scale">
                                            <img src="assets/images/bed.png" alt="" width=30px
                                                style="margin-right: 2rem;">
                                            <div>Spring Mattress</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="info">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="designer">
                        <div class="box">
                            <div class="image">
                                <img src="assets/images/couch4.jpg" alt="Alternate Text" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#product"><i
                                    class="icon icon-user"></i>Collection</a></li>
                        <li><a data-toggle="tab" href="#build"><i
                                    class="icon icon-sort-alpha-asc"></i>Specification</a></li>

                    </ul>
                    <div class="tab-content">
                        <div id="product" class="tab-pane active">
                            <div class="content">
                                <h3>Spring Mattress 6"</h3>
                                <p>Spring mattresses sandwich balanced layers of foam and spring that enriches
                                    your sleep quality. Quilted cover along with multiple layers of comfort foam
                                    elevates your sleeping experience. *The color of the mattress may vary from
                                    the image.*</p>
                                <strong>Quantity:<spam>1 unit</spam></strong>
                            </div>
                        </div>
                        <div id="build" class="tab-pane">
                            <div class="content">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="d-flex scale">
                                            <img src="assets/images/ruler.png" alt="" width=30px
                                                style="margin-right: 2rem;">
                                            <div>
                                                198.12 cm x 152.4 cm x 15.24 cm
                                            </div>
                                        </div>
                                        <div class=" scale">
                                            <img src="assets/images/bed.png" alt="" width=30px
                                                style="margin-right: 2rem;">
                                            <div>Spring Mattress</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/info-->
</section>

<div class="container photo">
    <h4>Photo Gallery</h4>
    <div id="slider-container" class="col-12 slider responsive">
        <div class="slide ">
            <img src="assets/images/couch2.jpg" alt="">
        </div>
        <div class="slide">
            <img src="assets/images/couch2.jpg" alt="">
        </div>
        <div class="slide">
            <img src="assets/images/couch2.jpg" alt="">
        </div>
        <div class="slide">
            <img src="assets/images/couch2.jpg" alt="">
        </div>
        <div class="slide">
            <img src="assets/images/couch2.jpg" alt="">
        </div>
        <div class="slide">
            <img src="assets/images/couch2.jpg" alt="">
        </div>
        <div class="slide">
            <img src="assets/images/couch2.jpg" alt="">
        </div>
        <div class="slide">
            <img src="assets/images/couch2.jpg" alt="">
        </div>
        <div onclick="prev()" class="control-prev-btn">
            <i class="fa fa-chevron-left" aria-hidden="true"></i>
        </div>
        <div onclick="next()" class="control-next-btn">
            <i class="fa fa-chevron-right" aria-hidden="true"></i>
        </div>
    </div>


    <div class="overlay"></div>
</div>



<script>
    function prev() {
        document.getElementById('slider-container').scrollLeft -= 270;
        // document.getElementById('slider-container').scrollLeft -= 400;
    }

    function next() {
        document.getElementById('slider-container').scrollLeft += 270;
        // document.getElementById('slider-container').scrollLeft += 400;
    }


    $(".slide img").on("click", function () {
        $(this).toggleClass('zoomed');
        $(".overlay").toggleClass('active');
    })
</script>

<div class="container">
    <div class="margin-tb-l">
        <div class="row">
            <div class="col padding-l font-weight-light font-size-20">
                <h4 class="photo">RentoFurnish Promise</h4>
            </div>
        </div>
        <div class="row" style="margin-bottom:3rem;">
            <div class="col-md-4 ">
                <div class="form-group">
                    <div class="container bg-white h-100 benefit-container">
                        <div class="row bg-primary  padding-rl-m align-items-center">
                            <div class="col-md-2  padding-l-m">

                                <!-- <i class="fa fa-map-marker" aria-hidden="true"></i> -->
                                <!-- <img src="assets/images/destination.png" class="s-30"> -->
                            </div>
                            <div class="col-md-10  padding-l-l font-color-snow font-size-16 font-weight-bold fwbold">
                                <img src="assets/images/destination.png" class="s-30">
                                Free Inter-city
                                Relocation</div>
                        </div>
                        <div class="row">
                            <div class="col font-weight-light padding-tb-l">We will relocate your RentoFurnish
                                furniture
                                for
                                free once a year between the cities we service.</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 ">
                <div class="form-group">
                    <div class="container bg-white h-100 benefit-container">
                        <div class="row bg-primary  padding-rl-m align-items-center">
                            <div class="col-md-2  padding-l-m">
                                <!-- <img src="assets/images/protection1.png" class="s-30"> -->
                            </div>
                            <div class="col-md-10  padding-l-l font-color-snow font-size-16 font-weight-light fwbold">
                                <img src="assets/images/protection1.png" class="s-30">
                                Safe &amp;
                                Sanitised
                            </div>
                        </div>
                        <div class="row">
                            <div class="col font-weight-light padding-tb-l">We deep clean your furniture right
                                before
                                delivery to ensure high-quality hygiene standards.</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 ">
                <div class="form-group">
                    <div class="container bg-white h-100 benefit-container">
                        <div class="row bg-primary  padding-rl-m align-items-center">
                            <div class="col-md-2  padding-l-m">
                                <!-- <img src="assets/images/medal.png" class="s-30"> -->
                                <!-- <i class="fa fa-star-o" aria-hidden="true"></i> -->
                            </div>
                            <div class="col-md-10  padding-l-l font-color-snow font-size-16 font-weight-light fwbold">
                                <img src="assets/images/medal.png" class="s-30">
                                Top-notch
                                Quality
                            </div>
                        </div>
                        <div class="row">
                            <div class="col font-weight-light padding-tb-l">We use premium quality steamed beech
                                wood or
                                rubber wood for a majority of products.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<section>
    <div class="container ">
        <h4 class="photo">FAQs about RentoFurnish Subscription</h4>
        <h6 class="photo">Solve your doubts about booking amount, cancellation, furniture exchange, relocation,
            etc</h6>
        <div>
            <button class="accordion"><strong class="fwbold">Is there a minimum rental tenure? What happens if I stop my
                    subscription before completing the
                    minimum tenure?</strong>
            </button>
            <div class="panel">
                <p style="padding: 1rem 0;">Yes, the minimum rental tenure is for 3 months. However, you can
                    choose to opt for a 3, 6, 9 or
                    12
                    months Renastic Saver Plan. The rent paid for the chosen plan is non-refundable in case you
                    choose
                    to terminate it before the rental tenure ends.</p>
            </div>
        </div>
        <div>
            <button class="accordion"><strong class="fwbold">Is there a cancellation fee if I place the order and cancel before
                    the products are delivered?</strong>
            </button>
            <div class="panel">
                <p style="padding: 1rem 0;">If you cancel the order before the products are delivered, you will
                    not be charged any
                    cancellation
                    fee. We will also refund your booking amount.</p>
            </div>
        </div>
        <div>
            <button class="accordion"><strong class="fwbold">I am shifting to a new city. Can I take my RentoFurnish
                    furniture?</strong>
            </button>
            <div class="panel">
                <p style="padding: 1rem 0;">Do not worry! We provide free intercity relocation, i.e. between the
                    cities where we are present,
                    once a year. So we will deliver all your RentoFurnish furniture to your new address free of
                    cost.</p>
            </div>
        </div>
        <div>
            <button class="accordion"><strong class="fwbold">Can I exchange the furniture if I don’t like it?</strong>
            </button>
            <div class="panel">
                <p style="padding: 1rem 0;">We recommend you to be present at the time of delivery and check the
                    products delivered to you.
                    If
                    you do not like the products at the time of delivery, you can return them immediately.</p>
                <p>Please note: Once delivery is completed, your rental tenure will begin immediately so all
                    cancellations will be non-refundable while your tenure is ongoing. However, you can choose
                    to
                    swap
                    your products after you complete your rental tenure.</p>
            </div>
        </div>
        <div>
            <button class="accordion"><strong class="fwbold">How can I terminate my subscription??</strong>
            </button>
            <div class="panel">
                <p style="padding: 1rem 0;">It’s super easy! You can terminate your subscription from your
                    RentoFurnish mobile app under the
                    account dashboard. Place a request with at least 7 days' notice to cancel the subscription
                    or to
                    return some of the products in your subscription.</p>
            </div>
        </div>
        <div>
            <button class="accordion"><strong class="fwbold">Do I have to submit any documents for my subscription?</strong>
            </button>
            <div class="panel">
                <p style="padding: 1rem 0;">Yes, you will need to provide your identity and address proof.</p>
            </div>
        </div>
        <div>
            <button class="accordion"><strong class="fwbold">Is there a booking amount?</strong>
            </button>
            <div class="panel">
                <p style="padding: 1rem 0;">No, there is no booking amount. You can just pick a Rentastic Saver
                    plan and continue with your subscription.</p>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <h4 class="photo">Customer Question & Answer</h4>

        <div class="contact-form-wrapper">

            <!-- <a class="btn open-form btn-main" data-text-open="Post Your Question" data-text-close="Close form"
                style="width: 19rem;">
                <p style="margin-top:1rem;">Post Your
                    Question</p>
            </a> -->

            <div class="contact-form clearfix" style="margin-top: 3rem;">
                <form id="" name="sendmail" action="" method="post">

                    <input type="text" class="form-control" placeholder="Enter your question here">
                    <h6 class="align-items-center">Please share your contact details so we can reach out to you
                        with the answer</h6>
                    <div class="row">
                        <div class="col-md-4 ">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Full Name">
                            </div>
                        </div>
                        <div class="col-md-4 ">
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Email Address">
                            </div>
                        </div>
                        <div class="col-md-4 ">
                            <div class="form-group">
                                <input type="phone" class="form-control" placeholder="Phone Number">
                            </div>
                        </div>
                    </div>
                    <div class="wrapper-more">
                        <button class=" btn btn-main" type="button" onclick="toastFunction()">submit</button>

                    </div>
                    <div id="toast">
                        <div class="checkicon"> <i class="fa fa-check-circle-o" aria-hidden="true"
                                style="color:green;"></i> </div>
                        your Question submitted successfully!
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<div class="popup-main mfp-hide" id="productid1">

    <!-- === product popup === -->

    <div class="product">

        <!-- === popup-title === -->

        <div class="popup-title">
            <div class="h1 title">Laura <small>product category</small></div>
        </div>

        <!-- === product gallery === -->

        <div class="owl-product-gallery">
            <img src="assets/images/product-1.png" alt="" width="640" />
            <img src="assets/images/product-2.png" alt="" width="640" />
            <img src="assets/images/product-3.png" alt="" width="640" />
            <img src="assets/images/product-4.png" alt="" width="640" />
        </div>

        <!-- === product-popup-info === -->

        <div class="popup-content">
            <div class="product-info-wrapper">
                <div class="row">

                    <!-- === left-column === -->

                    <div class="col-sm-6">
                        <div class="info-box">
                            <strong>Maifacturer</strong>
                            <span>Brand name</span>
                        </div>
                        <div class="info-box">
                            <strong>Materials</strong>
                            <span>Wood, Leather, Acrylic</span>
                        </div>
                        <div class="info-box">
                            <strong>Availability</strong>
                            <span><i class="fa fa-check-square-o"></i> in stock</span>
                        </div>
                    </div>

                    <!-- === right-column === -->

                    <div class="col-sm-6">
                        <div class="info-box">
                            <strong>Available Colors</strong>
                            <div class="product-colors clearfix">
                                <span class="color-btn color-btn-red"></span>
                                <span class="color-btn color-btn-blue checked"></span>
                                <span class="color-btn color-btn-green"></span>
                                <span class="color-btn color-btn-gray"></span>
                                <span class="color-btn color-btn-biege"></span>
                            </div>
                        </div>
                        <div class="info-box">
                            <strong>Choose size</strong>
                            <div class="product-colors clearfix">
                                <span class="color-btn color-btn-biege">S</span>
                                <span class="color-btn color-btn-biege checked">M</span>
                                <span class="color-btn color-btn-biege">XL</span>
                                <span class="color-btn color-btn-biege">XXL</span>
                            </div>
                        </div>
                    </div>

                </div>
                <!--/row-->
            </div>
            <!--/product-info-wrapper-->
        </div>
        <!--/popup-content-->
        <!-- === product-popup-footer === -->

        <div class="popup-table">
            <div class="popup-cell">
                <div class="price">
                    <span class="h3">₹ 1999,00 <small>₹ 2999,00</small></span>
                </div>
            </div>
            <div class="popup-cell">
                <div class="popup-buttons">
                    <a href="product.php"><span class="icon icon-eye"></span> <span class="hidden-xs">View
                            more</span></a>
                    <a href="javascript:void(0);"><span class="icon icon-cart"></span> <span
                            class="hidden-xs">Rent</span></a>
                    <!-- <a href="javascript:void(0);"><span class="icon icon-cart"></span> <span class="hidden-xs">add ons</span></a> -->

                </div>
            </div>
        </div>

    </div>
    <!--/product-->
</div>
<script>
    function showAlert() {
        var myAlert = document.getElementById("myAlert");
        move();
        myAlert.className = "show";
        setTimeout(function () {
            hideAlert();
        }, 5000);
    }

    function hideAlert() {
        myAlert.className = myAlert.className.replace("show", "");
    }
    var i = 0;

    function move() {
        if (i == 0) {
            var elem = document.getElementById("myAlertBar");
            var width = 1;
            var interval = setInterval(frame, 100);

            function frame() {
                if (width >= 100) {
                    clearInterval(id);
                    interval = 0;
                } else {
                    width++;
                    elem.style.width = width + "%";
                }
            }
        }
    }
</script>
<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();
</script>

<script>
    var acc = document.getElementsByClassName("accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function () {
            this.classList.toggle("active1");
            var panel = this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            }
        });
    }
</script>
<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();
</script>


<script>
    function toastFunction() {
        var x = document.getElementById("toast");
        x.className = "show";
        setTimeout(function () {
            x.className = x.className.replace("show", "");
        }, 3000);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rentOfFurnish\resources\views/layouts/product.blade.php ENDPATH**/ ?>